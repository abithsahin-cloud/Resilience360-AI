import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, Polyline, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { useResilience } from '../../context/ResilienceContext';

// Fix standard Leaflet default icon asset paths in Vite
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const warehouseIcon = new L.DivIcon({
  className: 'custom-div-icon',
  html: `<div style="background-color: #22C5D8; width: 14px; height: 14px; border-radius: 50%; border: 2px solid white; box-shadow: 0 0 10px #22C5D8;"></div>`,
  iconSize: [14, 14],
});

const incidentIcon = new L.DivIcon({
  className: 'custom-div-icon',
  html: `<div style="background-color: #DC4545; width: 16px; height: 16px; border-radius: 50%; border: 2px solid white; box-shadow: 0 0 12px #DC4545; animation: pulse 1.5s infinite;"></div>`,
  iconSize: [16, 16],
});

// Helper component to handle map responsiveness on resize & orientation changes
const MapController: React.FC<{ center: [number, number] }> = ({ center }) => {
  const map = useMap();
  
  useEffect(() => {
    const handleResize = () => {
      map.invalidateSize();
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);

    const timer = setTimeout(() => {
      map.invalidateSize();
      map.setView(center, 11);
    }, 250);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
      clearTimeout(timer);
    };
  }, [center, map]);

  return null;
};

export const GeospatialMap: React.FC = () => {
  const { selectedDistrict, isSimulatingDisaster } = useResilience();
  const [isMounted, setIsMounted] = useState(false);
  const [activeLayers, setActiveLayers] = useState({
    weatherRadar: true,
    floodZones: true,
    warehouses: true,
    supplyRoutes: true,
  });

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const centerCoords: [number, number] = [
    selectedDistrict?.latitude || 11.1271,
    selectedDistrict?.longitude || 78.6569,
  ];

  const simulatedRoute: [number, number][] = [
    [centerCoords[0] - 0.05, centerCoords[1] - 0.04],
    [centerCoords[0] - 0.02, centerCoords[1] - 0.01],
    centerCoords,
  ];

  if (!isMounted) {
    return <div className="w-full h-[520px] bg-[#111C2E] rounded-2xl flex items-center justify-center text-slate-400 text-xs">Loading Geospatial Intelligence Theatre...</div>;
  }

  return (
    <div className="relative w-full h-[520px] min-h-[450px] rounded-2xl overflow-hidden border border-[#2B3B50] shadow-2xl z-0">
      {/* Layer Control Bar */}
      <div className="absolute top-4 right-4 z-[400] bg-[#111C2E]/95 backdrop-blur-md p-3 rounded-xl border border-[#2B3B50] text-xs text-white space-y-2 shadow-2xl">
        <div className="font-semibold text-[#22C5D8] mb-1">Geospatial Intelligence Layers</div>
        <label className="flex items-center space-x-2 cursor-pointer">
          <input
            type="checkbox"
            checked={activeLayers.floodZones}
            onChange={e => setActiveLayers({ ...activeLayers, floodZones: e.target.checked })}
            className="rounded border-slate-700 text-[#22C5D8] focus:ring-0"
          />
          <span>Inundation Exposure Risk</span>
        </label>
        <label className="flex items-center space-x-2 cursor-pointer">
          <input
            type="checkbox"
            checked={activeLayers.warehouses}
            onChange={e => setActiveLayers({ ...activeLayers, warehouses: e.target.checked })}
            className="rounded border-slate-700 text-[#22C5D8] focus:ring-0"
          />
          <span>Relief Supply Depots</span>
        </label>
        <label className="flex items-center space-x-2 cursor-pointer">
          <input
            type="checkbox"
            checked={activeLayers.supplyRoutes}
            onChange={e => setActiveLayers({ ...activeLayers, supplyRoutes: e.target.checked })}
            className="rounded border-slate-700 text-[#22C5D8] focus:ring-0"
          />
          <span>Evacuation / Supply Corridor</span>
        </label>
      </div>

      <MapContainer
        key={`${centerCoords[0]}-${centerCoords[1]}`}
        center={centerCoords}
        zoom={11}
        scrollWheelZoom={false}
        style={{ width: '100%', height: '100%', backgroundColor: '#0B1220' }}
      >
        <MapController center={centerCoords} />
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        />

        {/* Selected District Center Point */}
        <Marker position={centerCoords}>
          <Popup>
            <div className="p-1 text-slate-900">
              <h4 className="font-bold">{selectedDistrict?.name || 'Tamil Nadu'} Center</h4>
              <p className="text-xs text-slate-600">Basin: {selectedDistrict?.major_river_basin || 'Cauvery'}</p>
            </div>
          </Popup>
        </Marker>

        {/* Flood Risk Buffer Zone */}
        {activeLayers.floodZones && isSimulatingDisaster && (
          <Circle
            center={centerCoords}
            radius={7500}
            pathOptions={{
              color: '#DC4545',
              fillColor: '#DC4545',
              fillOpacity: 0.4,
              weight: 2,
              dashArray: '4, 8',
            }}
          >
            <Popup>Critical Inundation Vulnerability Zone (Simulation Mode)</Popup>
          </Circle>
        )}

        {/* Emergency Supply Depot Warehouse */}
        {activeLayers.warehouses && (
          <Marker
            position={[centerCoords[0] - 0.05, centerCoords[1] - 0.04]}
            icon={warehouseIcon}
          >
            <Popup>
              <div className="text-slate-900">
                <span className="font-bold">Regional Supply Depot #1</span>
                <p className="text-xs">Capacity: 85% available</p>
              </div>
            </Popup>
          </Marker>
        )}

        {/* Active Emergency Incident Marker */}
        {isSimulatingDisaster && (
          <Marker
            position={[centerCoords[0] + 0.02, centerCoords[1] + 0.03]}
            icon={incidentIcon}
          >
            <Popup>
              <div className="text-slate-900">
                <span className="font-bold text-red-600">CRITICAL: Breached Embankment</span>
                <p className="text-xs">Est. Impact: 4,200 households</p>
              </div>
            </Popup>
          </Marker>
        )}

        {/* Evacuation Supply Routing Line */}
        {activeLayers.supplyRoutes && isSimulatingDisaster && (
          <Polyline
            positions={simulatedRoute}
            pathOptions={{ color: '#22C5D8', weight: 4, dashArray: '6, 6' }}
          />
        )}
      </MapContainer>
    </div>
  );
};
