import React, { createContext, useContext, useState, useEffect } from 'react';

interface DemoModeContextType {
  isDemoMode: boolean;
  toggleDemoMode: () => void;
  setDemoMode: (val: boolean) => void;
  notifications: { id: string; title: string; message: string; time: string; type: 'info' | 'warning' | 'critical' }[];
  addNotification: (notif: { title: string; message: string; type: 'info' | 'warning' | 'critical' }) => void;
}

const DemoModeContext = createContext<DemoModeContextType | undefined>(undefined);

export const DemoModeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isDemoMode, setIsDemoMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('resilience360_demo_mode');
    return saved !== null ? JSON.parse(saved) : true; // Default to TRUE for zero-key demo mode out of the box
  });

  const [notifications, setNotifications] = useState<
    { id: string; title: string; message: string; time: string; type: 'info' | 'warning' | 'critical' }[]
  >([
    { id: '1', title: 'System Initialized', message: 'RESILIENCE360 AI running in Zero-Key Demonstration Mode.', time: 'Just now', type: 'info' },
    { id: '2', title: 'Open-Meteo Feed', message: 'Weather telemetry synchronized for Tamil Nadu river basins.', time: '5m ago', type: 'info' },
    { id: '3', title: 'Grid Telemetry', message: 'TANGEDCO substation load levels nominal across Cuddalore and Chennai.', time: '12m ago', type: 'info' },
  ]);

  useEffect(() => {
    localStorage.setItem('resilience360_demo_mode', JSON.stringify(isDemoMode));
  }, [isDemoMode]);

  const toggleDemoMode = () => {
    setIsDemoMode(prev => !prev);
    addNotification({
      title: 'Operating Mode Changed',
      message: `Switched to ${!isDemoMode ? 'Demo Mode (Simulated Data)' : 'Live API Mode'}`,
      type: 'warning'
    });
  };

  const setDemoMode = (val: boolean) => {
    setIsDemoMode(val);
  };

  const addNotification = (notif: { title: string; message: string; type: 'info' | 'warning' | 'critical' }) => {
    const newNotif = {
      id: Date.now().toString(),
      ...notif,
      time: 'Just now',
    };
    setNotifications(prev => [newNotif, ...prev.slice(0, 19)]);
  };

  return (
    <DemoModeContext.Provider value={{ isDemoMode, toggleDemoMode, setDemoMode, notifications, addNotification }}>
      {children}
    </DemoModeContext.Provider>
  );
};

export const useDemoMode = () => {
  const context = useContext(DemoModeContext);
  if (!context) throw new Error('useDemoMode must be used within DemoModeProvider');
  return context;
};
