import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

export type UserRole = 
  | 'super_admin'
  | 'govt_admin'
  | 'agricultural_user'
  | 'climate_analyst'
  | 'resource_manager'
  | 'emergency_coordinator'
  | 'public_viewer';

export interface UserProfile {
  id: string;
  fullName: string;
  role: UserRole;
  organization: string;
  phone: string;
}

interface AuthContextType {
  user: any | null;
  profile: UserProfile | null;
  loading: boolean;
  signInAsRole: (role: UserRole) => void;
  signOut: () => void;
  hasRole: (allowedRoles: UserRole[]) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<any | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>({
    id: 'demo-user-123',
    fullName: 'Dr. Arul Kumaran (State Coordinator)',
    role: 'super_admin',
    organization: 'Tamil Nadu State Disaster Management Authority (TNSDMA)',
    phone: '+91 98400 12345'
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Check active session or persistence
    const storedRole = localStorage.getItem('resilience360_active_role') as UserRole;
    if (storedRole) {
      setProfile(prev => prev ? { ...prev, role: storedRole } : null);
    }
  }, []);

  const signInAsRole = (role: UserRole) => {
    const roleTitles: Record<UserRole, { name: string; org: string }> = {
      super_admin: { name: 'Dr. Arul Kumaran (Super Admin)', org: 'TNSDMA Executive' },
      govt_admin: { name: 'District Collector (Cuddalore)', org: 'District Administration' },
      agricultural_user: { name: 'Selvam Muthu (Farmer Producer Org)', org: 'Cauvery Delta FPO' },
      climate_analyst: { name: 'Dr. Meenakshi Sundaram', org: 'IMD / Climate Research Cell' },
      resource_manager: { name: 'Karthik Narayanan', org: 'TANGEDCO Grid Operations' },
      emergency_coordinator: { name: 'Commandant Rajeshwari', org: 'SDRF Rapid Response' },
      public_viewer: { name: 'Citizen Observer', org: 'Public Access' },
    };

    const info = roleTitles[role] || { name: 'User', org: 'General' };
    const newProfile: UserProfile = {
      id: `user-${role}`,
      fullName: info.name,
      role,
      organization: info.org,
      phone: '+91 94431 00000'
    };

    setProfile(newProfile);
    localStorage.setItem('resilience360_active_role', role);
  };

  const signOut = () => {
    setProfile(null);
    localStorage.removeItem('resilience360_active_role');
  };

  const hasRole = (allowedRoles: UserRole[]) => {
    if (!profile) return false;
    if (profile.role === 'super_admin') return true;
    return allowedRoles.includes(profile.role);
  };

  return (
    <AuthContext.Provider value={{ user, profile, loading, signInAsRole, signOut, hasRole }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
