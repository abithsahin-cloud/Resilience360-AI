import React, { createContext, useContext, useState, useEffect } from 'react';
import { District, LiveWeatherData, UnifiedResilienceInsight } from '../types';
import { fetchLiveDistrictWeather } from '../lib/openmeteo';
import { runUnifiedIntelligenceEngine } from '../lib/gemini';

export const TN_DISTRICTS: District[] = [
  { id: 1, name: 'Cuddalore', state: 'Tamil Nadu', latitude: 11.748, longitude: 79.7714, coastal: true, major_river_basin: 'Pennaiyar', soil_primary: 'Alluvial' },
  { id: 2, name: 'Chennai', state: 'Tamil Nadu', latitude: 13.0827, longitude: 80.2707, coastal: true, major_river_basin: 'Adyar / Cooum', soil_primary: 'Coastal Sand' },
  { id: 3, name: 'Thanjavur', state: 'Tamil Nadu', latitude: 10.787, longitude: 79.1378, coastal: false, major_river_basin: 'Cauvery Delta', soil_primary: 'Clay Alluvial' },
  { id: 4, name: 'Madurai', state: 'Tamil Nadu', latitude: 9.9252, longitude: 78.1198, coastal: false, major_river_basin: 'Vaigai', soil_primary: 'Red Loam' },
  { id: 5, name: 'Coimbatore', state: 'Tamil Nadu', latitude: 11.0168, longitude: 76.9558, coastal: false, major_river_basin: 'Noyyal', soil_primary: 'Black Soil' },
];

interface ResilienceContextType {
  selectedDistrict: District;
  setSelectedDistrict: (district: District) => void;
  weatherData: LiveWeatherData | null;
  intelligenceInsight: UnifiedResilienceInsight | null;
  isSimulatingDisaster: boolean;
  simulationStep: number;
  startEmergencySimulation: () => void;
  advanceSimulationStep: () => void;
  resetSimulation: () => void;
  refreshIntelligence: () => Promise<void>;
  loading: boolean;
}

const ResilienceContext = createContext<ResilienceContextType | undefined>(undefined);

export const ResilienceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [selectedDistrict, setSelectedDistrict] = useState<District>(TN_DISTRICTS[0]);
  const [weatherData, setWeatherData] = useState<LiveWeatherData | null>(null);
  const [intelligenceInsight, setIntelligenceInsight] = useState<UnifiedResilienceInsight | null>(null);
  const [isSimulatingDisaster, setIsSimulatingDisaster] = useState(false);
  const [simulationStep, setSimulationStep] = useState(1);
  const [loading, setLoading] = useState(false);

  const loadData = async (district: District, isSimulation: boolean = false) => {
    setLoading(true);
    try {
      const weather = await fetchLiveDistrictWeather(district.latitude, district.longitude);
      
      if (isSimulation) {
        weather.precipitation = 148.5; // Simulate Extreme Cloudburst
        weather.temperature = 24.2;
        weather.windSpeed = 68.0;
        weather.origin = 'SIMULATED';
      }

      setWeatherData(weather);

      const mockSensorReadings = {
        gridLoadMW: isSimulation ? 1420 : 890,
        gridCapacityMW: 1500,
        reservoirFillPct: isSimulation ? 96.5 : 62.0,
        substationStatus: isSimulation ? 'ALERT_WARNING' : 'NORMAL'
      };

      const insight = await runUnifiedIntelligenceEngine(district.name, weather, mockSensorReadings, isSimulation);
      setIntelligenceInsight(insight);
    } catch (e) {
      console.error('Failed to load resilience state:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData(selectedDistrict, isSimulatingDisaster);
  }, [selectedDistrict]);

  const startEmergencySimulation = () => {
    setIsSimulatingDisaster(true);
    setSimulationStep(1);
    loadData(selectedDistrict, true);
  };

  const advanceSimulationStep = () => {
    setSimulationStep(prev => (prev < 4 ? prev + 1 : prev));
  };

  const resetSimulation = () => {
    setIsSimulatingDisaster(false);
    setSimulationStep(1);
    loadData(selectedDistrict, false);
  };

  const refreshIntelligence = async () => {
    await loadData(selectedDistrict, isSimulatingDisaster);
  };

  return (
    <ResilienceContext.Provider
      value={{
        selectedDistrict,
        setSelectedDistrict,
        weatherData,
        intelligenceInsight,
        isSimulatingDisaster,
        simulationStep,
        startEmergencySimulation,
        advanceSimulationStep,
        resetSimulation,
        refreshIntelligence,
        loading
      }}
    >
      {children}
    </ResilienceContext.Provider>
  );
};

export const useResilience = () => {
  const context = useContext(ResilienceContext);
  if (!context) throw new Error('useResilience must be used within ResilienceProvider');
  return context;
};
