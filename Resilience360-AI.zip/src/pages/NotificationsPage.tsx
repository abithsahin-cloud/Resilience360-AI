import React from 'react';
import { useDemoMode } from '../context/DemoModeContext';
import { Bell, AlertTriangle, Info, CheckCircle2 } from 'lucide-react';

export const NotificationsPage: React.FC = () => {
  const { notifications } = useDemoMode();

  return (
    <div className="min-h-screen bg-[#0B1220] text-slate-100 p-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-800 pb-5 gap-4">
        <div>
          <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold uppercase tracking-wider">
            <Bell className="w-4 h-4" />
            <span>Real-Time Alert Feed & Notifications</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white mt-1">Operational Notification Center</h1>
          <p className="text-slate-400 text-xs mt-1">
            System broadcasts, automated URIE warnings, and emergency dispatch logs.
          </p>
        </div>
      </div>

      {/* Notifications List */}
      <div className="space-y-3 max-w-3xl">
        {notifications.map((n) => (
          <div key={n.id} className="bg-[#172338] p-4 rounded-xl border border-slate-800 flex items-start space-x-4 shadow-lg">
            <div className={`p-2.5 rounded-xl shrink-0 ${
              n.type === 'critical' ? 'bg-red-500/20 text-red-400' :
              n.type === 'warning' ? 'bg-amber-500/20 text-amber-400' :
              'bg-cyan-500/20 text-cyan-400'
            }`}>
              <AlertTriangle className="w-5 h-5" />
            </div>

            <div className="flex-1">
              <div className="flex justify-between items-center">
                <h4 className="font-bold text-white text-sm">{n.title}</h4>
                <span className="text-[10px] text-slate-400 font-mono">{n.time}</span>
              </div>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">{n.message}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
