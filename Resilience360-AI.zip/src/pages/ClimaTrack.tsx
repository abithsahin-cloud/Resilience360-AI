import React from 'react';
import { useResilience } from '../context/ResilienceContext';
import { useDemoMode } from '../context/DemoModeContext';
import { CloudRain, Thermometer, Wind, Droplets, ShieldAlert } from 'lucide-react';

export const ClimaTrack: React.FC = () => {
  const { selectedDistrict, weatherData, isSimulatingDisaster } = useResilience();
  const { isDemoMode } = useDemoMode();

  return (
    <div className="min-h-screen bg-[#0B1220] text-slate-100 p-6 lg:p-8 space-y-8">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-[#2B3B50] pb-6 gap-4">
        <div>
          <div className="flex items-center space-x-2 text-[#3689E8] text-xs font-bold uppercase tracking-wider">
            <CloudRain className="w-4 h-4" />
            <span>ClimaTrack Environmental Intelligence</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-extrabold text-white mt-1">Real-Time Atmospheric & Hazard Analytics</h1>
          <p className="text-slate-400 text-xs mt-1">
            Open-Meteo meteorological telemetry and multi-hazard risk assessment for {selectedDistrict.name}. {isDemoMode && <span className="text-amber-400 font-semibold">(DEMO MODE)</span>}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-[#111C2E] p-6 rounded-2xl border border-[#2B3B50] space-y-3 shadow-xl">
          <div className="flex items-center space-x-2 text-[#3689E8] text-xs font-bold uppercase">
            <Thermometer className="w-4 h-4" />
            <span>Temperature</span>
          </div>
          <div className="text-3xl font-extrabold text-white">{weatherData?.temperature ?? '--'}°C</div>
          <p className="text-xs text-slate-400">Current ambient reading</p>
        </div>

        <div className="bg-[#111C2E] p-6 rounded-2xl border border-[#2B3B50] space-y-3 shadow-xl">
          <div className="flex items-center space-x-2 text-[#22C5D8] text-xs font-bold uppercase">
            <Droplets className="w-4 h-4" />
            <span>Relative Humidity</span>
          </div>
          <div className="text-3xl font-extrabold text-white">{weatherData?.relativeHumidity ?? '--'}%</div>
          <p className="text-xs text-slate-400">Atmospheric moisture content</p>
        </div>

        <div className="bg-[#111C2E] p-6 rounded-2xl border border-[#2B3B50] space-y-3 shadow-xl">
          <div className="flex items-center space-x-2 text-[#16A36A] text-xs font-bold uppercase">
            <CloudRain className="w-4 h-4" />
            <span>Precipitation Rate</span>
          </div>
          <div className="text-3xl font-extrabold text-white">{weatherData?.precipitation ?? '--'} mm/h</div>
          <p className="text-xs text-slate-400">{isSimulatingDisaster ? 'Cloudburst anomaly active' : 'Normal rainfall'}</p>
        </div>

        <div className="bg-[#111C2E] p-6 rounded-2xl border border-[#2B3B50] space-y-3 shadow-xl">
          <div className="flex items-center space-x-2 text-[#F59E0B] text-xs font-bold uppercase">
            <Wind className="w-4 h-4" />
            <span>Wind Velocity</span>
          </div>
          <div className="text-3xl font-extrabold text-white">{weatherData?.windSpeed ?? '--'} km/h</div>
          <p className="text-xs text-slate-400">Surface vector</p>
        </div>
      </div>

      <div className="bg-[#111C2E] p-6 lg:p-8 rounded-2xl border border-[#2B3B50] space-y-6 shadow-xl">
        <div className="flex items-center space-x-2 text-[#3689E8] font-bold text-sm">
          <ShieldAlert className="w-4 h-4" />
          <span>Regional Multi-Hazard Risk Matrix</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
          <div className="bg-[#172438] p-5 rounded-xl border border-[#2B3B50] space-y-3">
            <div className="font-bold text-white text-sm">Flood & Inundation Risk</div>
            <div className="flex justify-between text-slate-400">
              <span>Risk Level:</span>
              <strong className={isSimulatingDisaster ? 'text-red-400' : 'text-[#16A36A]'}>
                {isSimulatingDisaster ? 'CRITICAL (89%)' : 'LOW (14%)'}
              </strong>
            </div>
            <p className="text-slate-400">River Basin: {selectedDistrict.major_river_basin}</p>
          </div>

          <div className="bg-[#172438] p-5 rounded-xl border border-[#2B3B50] space-y-3">
            <div className="font-bold text-white text-sm">Agricultural Drought Index</div>
            <div className="flex justify-between text-slate-400">
              <span>SPI Score:</span>
              <strong className="text-[#16A36A]">Normal (+0.4)</strong>
            </div>
            <p className="text-slate-400">Soil moisture retention optimal for current season.</p>
          </div>

          <div className="bg-[#172438] p-5 rounded-xl border border-[#2B3B50] space-y-3">
            <div className="font-bold text-white text-sm">Heat Stress Vulnerability</div>
            <div className="flex justify-between text-slate-400">
              <span>WBGT Index:</span>
              <strong className="text-[#F59E0B]">Moderate (28.5°C)</strong>
            </div>
            <p className="text-slate-400">Standard hydration advisories active for field workers.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
