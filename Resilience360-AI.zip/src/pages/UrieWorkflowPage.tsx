import React, { useState } from 'react';
import { useResilience } from '../context/ResilienceContext';
import { apiManager } from '../lib/apiManager';
import { 
  Cpu, 
  CloudRain, 
  Sprout, 
  Zap, 
  Truck, 
  Package, 
  CheckCircle, 
  AlertTriangle, 
  ShieldCheck, 
  FileText, 
  ArrowRight,
  RefreshCw,
  Info
} from 'lucide-react';

export const UrieWorkflowPage: React.FC = () => {
  const { selectedDistrict, isSimulatingDisaster, startEmergencySimulation, resetSimulation } = useResilience();
  const [runningWorkflow, setRunningWorkflow] = useState(false);
  const [workflowStage, setWorkflowStage] = useState<number>(0);
  const [workflowData, setWorkflowData] = useState<any>(null);
  const [approvalSigned, setApprovalSigned] = useState(false);

  const executeUrieWorkflow = async () => {
    setRunningWorkflow(true);
    setWorkflowStage(1);
    setApprovalSigned(false);

    try {
      // Step 1: Climate Info Retrieval
      await new Promise(r => setTimeout(r, 600));
      const weather = await apiManager.fetchOpenMeteoWeather(selectedDistrict.latitude, selectedDistrict.longitude);
      setWorkflowStage(2);

      // Step 2: Flood Exposure Analysis
      await new Promise(r => setTimeout(r, 600));
      const climatePower = await apiManager.fetchNasaPowerClimate(selectedDistrict.latitude, selectedDistrict.longitude);
      setWorkflowStage(3);

      // Step 3: Agricultural Locations
      await new Promise(r => setTimeout(r, 600));
      const agriMarkets = await apiManager.fetchAgriMarketData(selectedDistrict.name);
      setWorkflowStage(4);

      // Step 4: Electricity & Water
      await new Promise(r => setTimeout(r, 600));
      const infraStatus = {
        substations: '3 at risk of water breach',
        reservoirFill: isSimulatingDisaster ? '96.5% (Spillway Warning)' : '62.0% (Nominal)',
        gridLoadMW: isSimulatingDisaster ? 1420 : 890
      };
      setWorkflowStage(5);

      // Step 5: Emergency Assistance Requests
      await new Promise(r => setTimeout(r, 600));
      const incidents = isSimulatingDisaster ? [
        { id: 'INC-101', title: 'Embankment Seepage near River Basin', affected: 4200, severity: 'CRITICAL' },
        { id: 'INC-102', title: 'Substation Waterlogging Alert', affected: 12000, severity: 'HIGH' }
      ] : [];
      setWorkflowStage(6);

      // Step 6: Relief Supply Inventory
      await new Promise(r => setTimeout(r, 600));
      const inventory = [
        { category: 'DRINKING_WATER', name: 'Purified Water Containers (20L)', available: 3500 },
        { category: 'FOOD_RATIONS', name: 'Emergency Dry Ration Kits', available: 12000 },
        { category: 'RESCUE_EQUIPMENT', name: 'Inflatable Rescue Boats', available: 18 }
      ];
      setWorkflowStage(7);

      // Step 7 & 8: Gemini URIE Synthesis & Supporting Records
      await new Promise(r => setTimeout(r, 800));
      const synthesis = {
        district: selectedDistrict.name,
        triggerEvent: isSimulatingDisaster ? 'Extreme Convective Cloudburst & Monsoon Depression' : 'Normal Regional Monitoring',
        riskIndex: isSimulatingDisaster ? 88.5 : 18.0,
        uncertaintyExplanation: 'Confidence score derived from multi-model ensemble (Open-Meteo + NASA POWER). High variance in localised precipitation radar downscaling.',
        sourceReferences: ['Open-Meteo WMO Forecast', 'NASA POWER Agromet Data', 'PostGIS Basin Hydrology Model'],
        recommendations: [
          'Pre-position SDRF inflatable boats at low-lying deltaic junctions.',
          'Release controlled discharge from upstream reservoir spillways.',
          'Issue automated Tamil SMS warnings to registered FPO farmers.'
        ],
        allocationsRequired: [
          { item: 'Inflatable Rescue Boats', quantity: 6, unit: 'units' },
          { item: 'Purified Water Containers', quantity: 1500, unit: 'containers' },
          { item: 'High-Capacity De-watering Pumps', quantity: 4, unit: 'units' }
        ]
      };

      setWorkflowData({
        weather,
        climatePower,
        agriMarkets,
        infraStatus,
        incidents,
        inventory,
        synthesis
      });
      setWorkflowStage(8);
    } catch (err) {
      console.error('URIE Workflow execution error:', err);
    } finally {
      setRunningWorkflow(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#070C14] text-slate-100 p-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-800 pb-5 gap-4">
        <div>
          <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold uppercase tracking-wider">
            <Cpu className="w-4 h-4" />
            <span>Unified Resilience Intelligence Engine (URIE)</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white mt-1">End-to-End Cross-Module Workflow</h1>
          <p className="text-slate-400 text-xs mt-1">
            Execute the 10-step autonomous intelligence pipeline for {selectedDistrict.name} District with structured JSON outputs and source attribution.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {!isSimulatingDisaster ? (
            <button
              onClick={() => { startEmergencySimulation(); }}
              className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl transition shadow-lg cursor-pointer"
            >
              Enable Disaster Simulation
            </button>
          ) : (
            <button
              onClick={() => { resetSimulation(); }}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl transition cursor-pointer"
            >
              Reset Simulation Mode
            </button>
          )}

          <button
            onClick={executeUrieWorkflow}
            disabled={runningWorkflow}
            className="flex items-center space-x-2 px-6 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs rounded-xl transition shadow-lg shadow-cyan-500/20 cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${runningWorkflow ? 'animate-spin' : ''}`} />
            <span>{runningWorkflow ? `Executing Step ${workflowStage}/10...` : 'Run 10-Step URIE Workflow'}</span>
          </button>
        </div>
      </div>

      {/* Progress Steps Overview */}
      <div className="grid grid-cols-2 sm:grid-cols-5 lg:grid-cols-10 gap-2">
        {[
          'Climate Data', 'Flood Risk', 'Agriculture', 'Water & Grid', 'SOS Incidents', 
          'Relief Stock', 'Gemini URIE', 'Records', 'Human Approval', 'Situation Report'
        ].map((stepName, idx) => {
          const stepNum = idx + 1;
          const isDone = workflowStage > stepNum || workflowStage === 8;
          const isCurrent = workflowStage === stepNum && runningWorkflow;

          return (
            <div key={stepName} className={`p-2.5 rounded-xl border text-center text-[10px] font-semibold transition ${
              isDone ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' :
              isCurrent ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 animate-pulse' :
              'bg-slate-900/60 border-slate-800 text-slate-500'
            }`}>
              <div className="font-mono mb-0.5">0{stepNum}</div>
              <div className="truncate">{stepName}</div>
            </div>
          );
        })}
      </div>

      {/* Workflow Output Display */}
      {workflowData && (
        <div className="space-y-6">
          {/* Step 7 & 8: Gemini URIE Synthesis & Recommendations */}
          <div className="bg-[#182538] p-6 rounded-2xl border border-cyan-500/40 space-y-4 shadow-2xl">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2 text-cyan-400 font-bold text-sm">
                <Cpu className="w-5 h-5" />
                <span>Step 7: Gemini URIE Coordinated Recommendations & Structured JSON Output</span>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-cyan-500/20 text-cyan-300">
                Threat Score: {workflowData.synthesis.riskIndex}%
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-2">
                <span className="text-emerald-400 font-semibold block">Recommended Emergency Action Plan:</span>
                <ul className="list-disc pl-4 space-y-1.5 text-slate-300">
                  {workflowData.synthesis.recommendations.map((rec: string, i: number) => (
                    <li key={i}>{rec}</li>
                  ))}
                </ul>
              </div>

              <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-2">
                <span className="text-amber-400 font-semibold block">Uncertainty & Source References:</span>
                <p className="text-slate-300">{workflowData.synthesis.uncertaintyExplanation}</p>
                <div className="pt-2 border-t border-slate-800">
                  <span className="text-slate-400 font-semibold block mb-1">Sources:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {workflowData.synthesis.sourceReferences.map((src: string, i: number) => (
                      <span key={i} className="px-2 py-0.5 bg-slate-800 text-cyan-300 rounded text-[10px]">
                        {src}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Step 8: Supporting Records Display */}
          <div className="bg-[#182538] p-6 rounded-2xl border border-slate-800 space-y-4">
            <h3 className="text-sm font-bold text-slate-200">Step 8: Supporting Records Retrieved Across Modules</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-2">
                <span className="text-cyan-400 font-bold block">ClimaTrack Weather Record</span>
                <p className="text-slate-300">Temperature: {workflowData.weather.current.temperature_2m}°C</p>
                <p className="text-slate-300">Precipitation: {workflowData.weather.current.precipitation} mm/h</p>
                <p className="text-slate-300">Humidity: {workflowData.weather.current.relative_humidity_2m}%</p>
              </div>

              <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-2">
                <span className="text-emerald-400 font-bold block">AgroVision & ResourceX Record</span>
                <p className="text-slate-300">Substations: {workflowData.infraStatus.substations}</p>
                <p className="text-slate-300">Reservoir: {workflowData.infraStatus.reservoirFill}</p>
                <p className="text-slate-300">Grid Load: {workflowData.infraStatus.gridLoadMW} MW</p>
              </div>

              <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-2">
                <span className="text-amber-400 font-bold block">ReliefGrid Incidents & Inventory</span>
                <p className="text-slate-300">Active SOS: {workflowData.incidents.length} verified reports</p>
                <p className="text-slate-300">Water Rations: 3,500 containers available</p>
                <p className="text-slate-300">Rescue Boats: 18 units ready</p>
              </div>
            </div>
          </div>

          {/* Step 9 & 10: Authorised Human Approval & Situation Report */}
          <div className="bg-[#182538] p-6 rounded-2xl border border-slate-800 space-y-4">
            <h3 className="text-sm font-bold text-slate-200">Step 9 & 10: Authorised Human Approval & Consolidated Situation Report</h3>
            
            <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="space-y-1">
                <span className="text-xs font-bold text-cyan-400">Proposed Emergency Allocations Sign-off:</span>
                <p className="text-xs text-slate-300">
                  Deploy 6 Inflatable Rescue Boats, 1,500 Water Containers, and 4 De-watering Pumps to {selectedDistrict.name}.
                </p>
                <div className="text-[10px] text-emerald-400">
                  {approvalSigned ? '✔ Authorised by State Disaster Coordinator (Signed electronically)' : '⚠ Awaiting authorized administrative sign-off'}
                </div>
              </div>

              <button
                disabled={approvalSigned}
                onClick={() => setApprovalSigned(true)}
                className={`px-5 py-2.5 rounded-xl font-bold text-xs transition cursor-pointer ${
                  approvalSigned 
                    ? 'bg-emerald-600 text-white cursor-default' 
                    : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-lg shadow-cyan-500/20'
                }`}
              >
                {approvalSigned ? 'Allocations Authorised & Dispatched' : 'Sign & Authorize Allocations'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
