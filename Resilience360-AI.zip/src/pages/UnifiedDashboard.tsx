import React, { useState } from 'react';
import { useResilience, TN_DISTRICTS } from '../context/ResilienceContext';
import { useDemoMode } from '../context/DemoModeContext';
import { GeospatialMap } from '../components/map/GeospatialMap';
import { 
  CloudRain, 
  AlertTriangle, 
  Zap, 
  Activity, 
  Truck, 
  Sparkles,
  RefreshCw,
  Radio,
  ChevronRight,
  ShieldAlert,
  Droplet,
  Sun,
  TrendingUp,
  MapPin,
  Calendar,
  CheckCircle2,
  Info,
  Layers
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, BarChart, Bar, CartesianGrid } from 'recharts';

export const UnifiedDashboard: React.FC = () => {
  const { 
    selectedDistrict, 
    setSelectedDistrict, 
    weatherData, 
    intelligenceInsight, 
    isSimulatingDisaster,
    startEmergencySimulation,
    resetSimulation,
    refreshIntelligence,
    loading 
  } = useResilience();

  const { isDemoMode } = useDemoMode();
  const [activeMapLayer, setActiveMapLayer] = useState<'weather' | 'flood' | 'drought' | 'heat' | 'agri' | 'infra' | 'incidents'>('flood');
  const [tickerIndex, setTickerIndex] = useState(0);

  const currentDate = new Date().toLocaleDateString('en-US', { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' });

  const notificationsList = [
    { id: 1, type: 'CRITICAL', text: `Flash flood risk elevated for ${selectedDistrict.name} river basin.`, time: '2m ago' },
    { id: 2, type: 'STATUS', text: 'TANGEDCO substation load balanced at 890 MW.', time: '12m ago' },
    { id: 3, type: 'AGRI', text: 'AgroVision satellite scan indicates optimal vegetative index for Paddy.', time: '25m ago' },
  ];

  const rainfallForecastData = weatherData?.forecastDates.map((date, idx) => ({
    date: date.slice(5),
    rain: weatherData.forecastRainSum[idx] || 0,
    temp: weatherData.forecastMaxTemp[idx] || 31,
  })) || [];

  const energyDemandData = [
    { time: '00:00', demand: 720, solar: 0 },
    { time: '04:00', demand: 680, solar: 0 },
    { time: '08:00', demand: 950, solar: 180 },
    { time: '12:00', demand: 1240, solar: 420 },
    { time: '16:00', demand: 1100, solar: 290 },
    { time: '20:00', demand: 890, solar: 0 },
  ];

  return (
    <div className="min-h-screen bg-[#0B1220] text-slate-100 p-4 sm:p-6 lg:p-8 space-y-6">
      {/* HEADER SECTION */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center bg-[#172338] p-5 sm:p-6 rounded-2xl border border-slate-800 shadow-xl gap-4">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-xs font-mono text-cyan-400 uppercase tracking-widest">
            <Calendar className="w-3.5 h-3.5" />
            <span>{currentDate} | Command Centre Operations</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Welcome back, Dr. Arul Kumaran
          </h1>
          <p className="text-xs text-slate-400">
            Active Geographical Sector: <strong className="text-white">{selectedDistrict.name} District, {selectedDistrict.state}</strong> {isDemoMode && <span className="text-amber-400 font-semibold">(DEMO DATA)</span>}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
          <select
            value={selectedDistrict.id}
            onChange={(e) => {
              const d = TN_DISTRICTS.find(item => item.id === Number(e.target.value));
              if (d) setSelectedDistrict(d);
            }}
            className="bg-[#0B1220] border border-slate-700 text-slate-200 text-xs rounded-xl px-3.5 py-2.5 outline-none focus:border-cyan-500 font-medium"
          >
            {TN_DISTRICTS.map((d) => (
              <option key={d.id} value={d.id}>{d.name} District</option>
            ))}
          </select>

          <button
            onClick={() => refreshIntelligence()}
            disabled={loading}
            className="flex items-center space-x-1.5 px-3.5 py-2.5 bg-slate-900 hover:bg-slate-800 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700 transition cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-cyan-400' : ''}`} />
            <span>Sync</span>
          </button>

          {!isSimulatingDisaster ? (
            <button
              onClick={startEmergencySimulation}
              className="flex items-center space-x-2 px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs transition shadow-lg shadow-red-950/50 cursor-pointer"
            >
              <AlertTriangle className="w-4 h-4" />
              <span>Simulate Cloudburst</span>
            </button>
          ) : (
            <button
              onClick={resetSimulation}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl text-xs transition cursor-pointer"
            >
              Reset Simulation
            </button>
          )}
        </div>
      </div>

      {/* FIRST SECTION — GLOBAL RESILIENCE STATUS (5 Important Indicators) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* 1. Environmental Risk */}
        <div className="bg-[#172338] p-4 sm:p-5 rounded-2xl border border-slate-800 space-y-2 hover:border-slate-700 transition">
          <div className="flex justify-between items-center text-slate-400">
            <span className="text-[11px] font-bold uppercase tracking-wider">Environmental Risk</span>
            <CloudRain className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-extrabold text-white">
            {isSimulatingDisaster ? 'Critical (88%)' : 'Low (18%)'}
          </div>
          <div className="text-[11px] text-cyan-400 flex items-center space-x-1">
            <span>Precipitation: {weatherData?.precipitation ?? 4.2} mm/h</span>
          </div>
        </div>

        {/* 2. Agricultural Health */}
        <div className="bg-[#172338] p-4 sm:p-5 rounded-2xl border border-slate-800 space-y-2 hover:border-slate-700 transition">
          <div className="flex justify-between items-center text-slate-400">
            <span className="text-[11px] font-bold uppercase tracking-wider">Agricultural Health</span>
            <Activity className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-extrabold text-white">Optimal (94%)</div>
          <div className="text-[11px] text-emerald-400">Delta Paddy Vegetation Active</div>
        </div>

        {/* 3. Water Availability */}
        <div className="bg-[#172338] p-4 sm:p-5 rounded-2xl border border-slate-800 space-y-2 hover:border-slate-700 transition">
          <div className="flex justify-between items-center text-slate-400">
            <span className="text-[11px] font-bold uppercase tracking-wider">Water Availability</span>
            <Droplet className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-extrabold text-white">
            {isSimulatingDisaster ? '96.5% (Spillway)' : '62.0% (Stable)'}
          </div>
          <div className="text-[11px] text-blue-400">Basin: {selectedDistrict.major_river_basin}</div>
        </div>

        {/* 4. Energy Availability */}
        <div className="bg-[#172338] p-4 sm:p-5 rounded-2xl border border-slate-800 space-y-2 hover:border-slate-700 transition">
          <div className="flex justify-between items-center text-slate-400">
            <span className="text-[11px] font-bold uppercase tracking-wider">Energy Availability</span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-extrabold text-white">
            {isSimulatingDisaster ? '1,420 MW Load' : '890 MW Load'}
          </div>
          <div className="text-[11px] text-amber-400">Grid Capacity: 1,500 MW</div>
        </div>

        {/* 5. Emergency Readiness */}
        <div className="bg-[#172338] p-4 sm:p-5 rounded-2xl border border-slate-800 space-y-2 hover:border-slate-700 transition sm:col-span-2 lg:col-span-1">
          <div className="flex justify-between items-center text-slate-400">
            <span className="text-[11px] font-bold uppercase tracking-wider">Emergency Readiness</span>
            <Truck className="w-4 h-4 text-orange-400" />
          </div>
          <div className="text-2xl font-extrabold text-white">
            {isSimulatingDisaster ? 'Red Alert' : 'Standby'}
          </div>
          <div className="text-[11px] text-orange-400">SDRF Units: 18 Deployed</div>
        </div>
      </div>

      {/* SECOND SECTION — GEOSPATIAL INTELLIGENCE & FOURTH SECTION — UNIFIED AI INTELLIGENCE */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Large Interactive Map (Occupying ~60% width on large screens = col-span-7 or 8) */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex flex-wrap justify-between items-center bg-[#172338] px-4 py-3 rounded-2xl border border-slate-800 gap-2">
            <div className="flex items-center space-x-2 text-xs font-bold text-slate-200">
              <MapPin className="w-4 h-4 text-cyan-400" />
              <span>Geospatial Intelligence Theatre ({selectedDistrict.name})</span>
            </div>

            {/* Selectable Geographical Layers */}
            <div className="flex flex-wrap gap-1">
              {[
                { id: 'flood', label: 'Flood' },
                { id: 'weather', label: 'Weather' },
                { id: 'drought', label: 'Drought' },
                { id: 'agri', label: 'Agri' },
                { id: 'infra', label: 'Infra' },
                { id: 'incidents', label: 'SOS' },
              ].map(layer => (
                <button
                  key={layer.id}
                  onClick={() => setActiveMapLayer(layer.id as any)}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
                    activeMapLayer === layer.id ? 'bg-cyan-500 text-slate-950 shadow' : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  {layer.label}
                </button>
              ))}
            </div>
          </div>

          <div className="w-full h-[540px] rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
            <GeospatialMap />
          </div>
        </div>

        {/* FOURTH SECTION — UNIFIED AI INTELLIGENCE (Prominent AI Situation Summary) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#172338] p-6 rounded-2xl border border-cyan-500/40 space-y-4 shadow-xl flex flex-col justify-between h-full">
            <div className="space-y-4">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                <div className="flex items-center space-x-2 text-cyan-400 font-bold text-sm">
                  <Sparkles className="w-4 h-4" />
                  <span>URIE AI Situation Summary</span>
                </div>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-500/20 text-cyan-300">
                  Confidence: {intelligenceInsight?.confidenceScore || 92.4}%
                </span>
              </div>

              <div className="space-y-3 text-xs text-slate-300">
                <div>
                  <span className="text-slate-400 font-semibold block mb-1">Detected Conditions:</span>
                  <p className="font-medium text-white">
                    {intelligenceInsight?.triggerEvent || 'Monsoon depression and heavy convective cloudburst active.'}
                  </p>
                </div>

                <div>
                  <span className="text-slate-400 font-semibold block mb-1">Potential Sectoral Impacts:</span>
                  <p className="text-slate-300 leading-relaxed">
                    {intelligenceInsight?.agriculturalImpact || 'High risk of paddy waterlogging and substation breach in low-lying basin zones.'}
                  </p>
                </div>

                <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800 space-y-2">
                  <span className="text-emerald-400 font-semibold block">Recommended Immediate Actions:</span>
                  <ul className="list-disc pl-4 space-y-1 text-slate-300">
                    {intelligenceInsight?.emergencyCoordinationPlan?.immediateActions.slice(0, 3).map((act, i) => (
                      <li key={i}>{act}</li>
                    )) || <li>Pre-position SDRF rescue boats and de-watering pumps.</li>}
                  </ul>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 text-[11px] text-slate-400 flex justify-between items-center">
              <span>Uncertainty: Low (Ensemble Verified)</span>
              <span className="text-cyan-400 font-mono">Source: Open-Meteo & PostGIS</span>
            </div>
          </div>
        </div>
      </div>

      {/* THIRD SECTION — ANALYTICS (Professional Visualisations) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#172338] p-6 rounded-2xl border border-slate-800 space-y-4 shadow-xl">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-bold text-slate-200">7-Day Rainfall & Temperature Forecast</h3>
            <span className="text-xs text-cyan-400 font-mono">Open-Meteo Live API</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={rainfallForecastData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#22324a" />
                <XAxis dataKey="date" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip contentStyle={{ backgroundColor: '#0B1220', borderColor: '#22324a', color: '#fff' }} />
                <Area type="monotone" dataKey="rain" stroke="#22C5D8" fill="#22C5D8" fillOpacity={0.25} name="Rainfall (mm)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-[#172338] p-6 rounded-2xl border border-slate-800 space-y-4 shadow-xl">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-bold text-slate-200">24-Hour Energy Demand vs Solar Generation (MW)</h3>
            <span className="text-xs text-amber-400 font-mono">TANGEDCO Telemetry</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={energyDemandData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#22324a" />
                <XAxis dataKey="time" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip contentStyle={{ backgroundColor: '#0B1220', borderColor: '#22324a', color: '#fff' }} />
                <Bar dataKey="demand" fill="#F59E0B" name="Grid Demand (MW)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="solar" fill="#16A36A" name="Solar Gen (MW)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* FIFTH SECTION — RECENT ACTIVITIES */}
      <div className="bg-[#172338] p-6 rounded-2xl border border-slate-800 space-y-4 shadow-xl">
        <h3 className="text-sm font-bold text-slate-200">Recent Operational Activities & Incident Feed</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
          <div className="bg-[#0B1220] p-4 rounded-xl border border-slate-800 space-y-2">
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-red-500/20 text-red-400">CRITICAL ALERT</span>
            <div className="font-bold text-white">Embankment Breach Watch</div>
            <p className="text-slate-400">Vellar River basin water level exceeds threshold. SDRF units alerted.</p>
            <span className="text-[10px] text-slate-500 block">12 mins ago • Cuddalore</span>
          </div>

          <div className="bg-[#0B1220] p-4 rounded-xl border border-slate-800 space-y-2">
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400">AGROVISION</span>
            <div className="font-bold text-white">Mandi Price Synchronized</div>
            <p className="text-slate-400">Agmarknet rates updated for Paddy Grade A (₹2,320 / Qtl).</p>
            <span className="text-[10px] text-slate-500 block">34 mins ago • Thanjavur</span>
          </div>

          <div className="bg-[#0B1220] p-4 rounded-xl border border-slate-800 space-y-2">
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-400">RESOURCEX</span>
            <div className="font-bold text-white">Substation Backup Active</div>
            <p className="text-slate-400">Substation #3 switched to backup diesel generators successfully.</p>
            <span className="text-[10px] text-slate-500 block">1 hour ago • Chennai</span>
          </div>
        </div>
      </div>
    </div>
  );
};
