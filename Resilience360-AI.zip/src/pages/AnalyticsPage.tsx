import React from 'react';
import { useResilience } from '../context/ResilienceContext';
import { useDemoMode } from '../context/DemoModeContext';
import { Activity, BarChart3, TrendingUp, ShieldAlert, Cpu } from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, BarChart, Bar, CartesianGrid } from 'recharts';

export const AnalyticsPage: React.FC = () => {
  const { selectedDistrict, weatherData } = useResilience();
  const { isDemoMode } = useDemoMode();

  const trendData = [
    { month: 'Jun', riskScore: 32, rainfall: 45, loadMW: 820 },
    { month: 'Jul', riskScore: 41, rainfall: 88, loadMW: 890 },
    { month: 'Aug', riskScore: 38, rainfall: 62, loadMW: 860 },
    { month: 'Sep', riskScore: 55, rainfall: 140, loadMW: 950 },
    { month: 'Oct', riskScore: 78, rainfall: 280, loadMW: 1250 },
    { month: 'Nov', riskScore: 84, rainfall: 345, loadMW: 1380 },
    { month: 'Dec', riskScore: 62, rainfall: 190, loadMW: 1100 },
  ];

  const sectoralImpactData = [
    { sector: 'Agriculture (Paddy)', exposurePct: 88 },
    { sector: 'Power Grid Substations', exposurePct: 64 },
    { sector: 'Water Reservoirs', exposurePct: 92 },
    { sector: 'Road & Transport', exposurePct: 45 },
    { sector: 'Coastal Habitation', exposurePct: 75 },
  ];

  return (
    <div className="min-h-screen bg-[#0B1220] text-slate-100 p-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-800 pb-5 gap-4">
        <div>
          <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold uppercase tracking-wider">
            <BarChart3 className="w-4 h-4" />
            <span>Enterprise Analytics & Predictive Intelligence</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white mt-1">Multi-Hazard Analytics Engine</h1>
          <p className="text-slate-400 text-xs mt-1">
            Historical monsoon correlation, sectoral risk exposure, and predictive climate modeling for {selectedDistrict.name}. {isDemoMode && <span className="text-amber-400 font-semibold">(DEMO MODE DATA)</span>}
          </p>
        </div>
      </div>

      {/* Analytics KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-[#172338] p-5 rounded-2xl border border-slate-800 space-y-2">
          <span className="text-xs font-semibold text-slate-400 uppercase">Composite Risk Index</span>
          <div className="text-3xl font-extrabold text-white">78.4 <span className="text-xs text-red-400 font-normal">/ 100 (HIGH)</span></div>
          <p className="text-xs text-slate-400">Based on antecedent soil moisture and basin runoff.</p>
        </div>

        <div className="bg-[#172338] p-5 rounded-2xl border border-slate-800 space-y-2">
          <span className="text-xs font-semibold text-slate-400 uppercase">Monsoon Anomaly</span>
          <div className="text-3xl font-extrabold text-cyan-400">+164%</div>
          <p className="text-xs text-slate-400">Precipitation departure from 30-year climatological baseline.</p>
        </div>

        <div className="bg-[#172338] p-5 rounded-2xl border border-slate-800 space-y-2">
          <span className="text-xs font-semibold text-slate-400 uppercase">Grid Peak Demand</span>
          <div className="text-3xl font-extrabold text-amber-400">1,380 MW</div>
          <p className="text-xs text-slate-400">Maximum projected load during extreme weather windows.</p>
        </div>

        <div className="bg-[#172338] p-5 rounded-2xl border border-slate-800 space-y-2">
          <span className="text-xs font-semibold text-slate-400 uppercase">URIE Model Confidence</span>
          <div className="text-3xl font-extrabold text-emerald-400">94.2%</div>
          <p className="text-xs text-slate-400">Ensemble verification across Open-Meteo & NASA POWER.</p>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#172338] p-6 rounded-2xl border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-slate-200">Monsoon Rainfall vs Composite Risk Trend</h3>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#22324a" />
                <XAxis dataKey="month" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip contentStyle={{ backgroundColor: '#0B1220', borderColor: '#22324a', color: '#fff' }} />
                <Area type="monotone" dataKey="rainfall" stroke="#3689E8" fill="#3689E8" fillOpacity={0.2} name="Rainfall (mm)" />
                <Area type="monotone" dataKey="riskScore" stroke="#DC4545" fill="#DC4545" fillOpacity={0.15} name="Risk Score (%)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-[#172338] p-6 rounded-2xl border border-slate-800 space-y-4">
          <h3 className="text-sm font-bold text-slate-200">Sectoral Vulnerability Exposure (%)</h3>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={sectoralImpactData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#22324a" />
                <XAxis type="number" stroke="#64748b" fontSize={11} />
                <YAxis dataKey="sector" type="category" stroke="#64748b" fontSize={11} width={130} />
                <Tooltip contentStyle={{ backgroundColor: '#0B1220', borderColor: '#22324a', color: '#fff' }} />
                <Bar dataKey="exposurePct" fill="#22C5D8" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
