import React, { useState } from 'react';
import { useResilience } from '../context/ResilienceContext';
import { useDemoMode } from '../context/DemoModeContext';
import { analyzeCropDiseaseImage } from '../lib/gemini';
import { Upload, Sparkles, CheckCircle2, IndianRupee, Sprout, ShieldAlert, ArrowUpRight } from 'lucide-react';

export const AgroVision: React.FC = () => {
  const { selectedDistrict } = useResilience();
  const { isDemoMode } = useDemoMode();
  const [analyzingImage, setAnalyzingImage] = useState(false);
  const [diagnosis, setDiagnosis] = useState<any>(null);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setAnalyzingImage(true);
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64String = (reader.result as string).split(',')[1];
      try {
        const result = await analyzeCropDiseaseImage(base64String, file.type);
        setDiagnosis(result);
      } catch (err) {
        console.error(err);
      } finally {
        setAnalyzingImage(false);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="min-h-screen bg-[#0B1220] text-slate-100 p-6 lg:p-8 space-y-8">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-[#2B3B50] pb-6 gap-4">
        <div>
          <div className="flex items-center space-x-2 text-[#16A36A] text-xs font-bold uppercase tracking-wider">
            <Sprout className="w-4 h-4" />
            <span>AgroVision Intelligence Workspace</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-extrabold text-white mt-1">Agricultural & Crop Pathology Copilot</h1>
          <p className="text-slate-400 text-xs mt-1">
            Multimodal leaf screening, seasonal crop suitability, and Agmarknet mandi rates for {selectedDistrict.name}. {isDemoMode && <span className="text-amber-400 font-semibold">(DEMO MODE)</span>}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Multimodal Disease Scanner */}
        <div className="bg-[#111C2E] p-6 rounded-2xl border border-[#2B3B50] space-y-4 shadow-xl">
          <div className="flex items-center space-x-2 text-[#16A36A] font-bold text-sm">
            <Sparkles className="w-4 h-4" />
            <span>AI Multimodal Plant Pathology Scanner</span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Upload high-resolution crop specimen photographs. Gemini Vision diagnoses fungal, bacterial, and pest vectors instantly.
          </p>

          <label className="border-2 border-dashed border-[#2B3B50] hover:border-[#16A36A]/60 rounded-xl p-8 flex flex-col items-center justify-center cursor-pointer transition bg-[#172438]/50 group">
            <Upload className="w-8 h-8 text-slate-500 group-hover:text-[#16A36A] mb-2 transition" />
            <span className="text-xs text-slate-300 font-semibold">Upload crop specimen leaf</span>
            <span className="text-[10px] text-slate-500 mt-1">PNG, JPG, WEBP up to 10MB</span>
            <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
          </label>

          {analyzingImage && (
            <div className="text-center py-4 text-xs text-[#22C5D8] animate-pulse">
              Running deep feature extraction via Gemini Vision...
            </div>
          )}

          {diagnosis && (
            <div className="bg-[#0B1220] p-4 rounded-xl border border-[#16A36A]/40 space-y-3 text-xs">
              <div className="flex justify-between items-center">
                <span className="font-bold text-[#16A36A] text-sm">{diagnosis.condition}</span>
                <span className="text-slate-400 font-mono bg-slate-900 px-2 py-0.5 rounded">{diagnosis.confidence}% Confidence</span>
              </div>
              <p className="text-slate-300 leading-relaxed">{diagnosis.symptoms}</p>
              <div className="border-t border-[#2B3B50] pt-3 mt-2">
                <span className="text-white font-semibold block mb-1.5">Recommended Interventions:</span>
                <ul className="list-disc pl-4 space-y-1 text-slate-400">
                  {diagnosis.recommendations.map((rec: string, i: number) => (
                    <li key={i}>{rec}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>

        {/* Dynamic Crop Suitability Engine */}
        <div className="bg-[#111C2E] p-6 rounded-2xl border border-[#2B3B50] space-y-4 shadow-xl">
          <div className="flex items-center space-x-2 text-[#22C5D8] font-bold text-sm">
            <CheckCircle2 className="w-4 h-4" />
            <span>Seasonal Crop Recommendation Matrix</span>
          </div>
          <p className="text-xs text-slate-400">Soil type: <strong className="text-white">{selectedDistrict.soil_primary}</strong></p>

          <div className="space-y-3">
            {[
              { crop: 'Paddy (ADT 45)', score: 94, duration: '115 Days', water: 'High', status: 'Optimal' },
              { crop: 'Black Gram (VBN 8)', score: 86, duration: '70 Days', water: 'Low', status: 'Optimal' },
              { crop: 'Groundnut (TMV 13)', score: 62, duration: '105 Days', water: 'Medium', status: 'Caution - Drainage' },
            ].map((item, idx) => (
              <div key={idx} className="bg-[#172438] p-4 rounded-xl border border-[#2B3B50] text-xs flex justify-between items-center">
                <div>
                  <div className="font-bold text-white text-sm">{item.crop}</div>
                  <div className="text-slate-400 text-[11px] mt-0.5">Harvest: {item.duration} | Water: {item.water}</div>
                </div>
                <div className="text-right">
                  <span className="text-[#16A36A] font-extrabold text-sm">{item.score}% Match</span>
                  <div className="text-[10px] text-slate-400 mt-0.5">{item.status}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Mandi Commodity Real-Time Rates */}
        <div className="bg-[#111C2E] p-6 rounded-2xl border border-[#2B3B50] space-y-4 shadow-xl">
          <div className="flex items-center space-x-2 text-[#F59E0B] font-bold text-sm">
            <IndianRupee className="w-4 h-4" />
            <span>Agmarknet Mandi Commodity Feed</span>
          </div>
          <p className="text-xs text-slate-400">Live regulated market modal prices.</p>

          <div className="space-y-3">
            {[
              { market: `${selectedDistrict.name} Regulated Market`, commodity: 'Paddy (Grade A)', modal: '₹2,320 / Qtl', trend: '+1.4%' },
              { market: `${selectedDistrict.name} Uzhavar Sandhai`, commodity: 'Groundnut Pods', modal: '₹6,450 / Qtl', trend: '-0.8%' },
              { market: 'Kaveripattinam Market', commodity: 'Sugarcane', modal: '₹3,150 / Ton', trend: '+0.0%' },
            ].map((mandi, idx) => (
              <div key={idx} className="bg-[#172438] p-4 rounded-xl border border-[#2B3B50] text-xs space-y-1">
                <div className="flex justify-between font-bold text-white">
                  <span>{mandi.commodity}</span>
                  <span className="text-[#16A36A] font-mono">{mandi.modal}</span>
                </div>
                <div className="flex justify-between text-[11px] text-slate-400">
                  <span>{mandi.market}</span>
                  <span className={mandi.trend.startsWith('+') ? 'text-[#16A36A]' : 'text-slate-400'}>{mandi.trend}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
