import React, { useState } from 'react';
import { useDemoMode } from '../context/DemoModeContext';
import { Settings, Shield, Server, Key, CheckCircle2, Save, ToggleLeft, ToggleRight } from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const { isDemoMode, toggleDemoMode } = useDemoMode();
  const [saved, setSaved] = useState(false);
  const [supabaseUrl, setSupabaseUrl] = useState(import.meta.env.VITE_SUPABASE_URL || '');
  const [geminiKey, setGeminiKey] = useState('••••••••••••••••••••••••');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="min-h-screen bg-[#0B1220] text-slate-100 p-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-800 pb-5 gap-4">
        <div>
          <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold uppercase tracking-wider">
            <Settings className="w-4 h-4" />
            <span>Administrator Integration Settings</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white mt-1">Platform Configuration & API Keys</h1>
          <p className="text-slate-400 text-xs mt-1">
            Configure external service endpoints, Supabase connections, and toggle between Zero-Key Demo Mode and Live Mode.
          </p>
        </div>
      </div>

      {saved && (
        <div className="bg-emerald-950/40 border border-emerald-500/50 p-4 rounded-xl text-xs text-emerald-300 flex items-center space-x-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>Configuration saved securely. Secret values are masked in storage.</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Settings Form */}
        <form onSubmit={handleSave} className="lg:col-span-2 bg-[#172338] p-6 rounded-2xl border border-slate-800 space-y-6">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-3">Operating Mode & Core Integrations</h3>

          <div className="flex items-center justify-between p-4 bg-slate-900 rounded-xl border border-slate-800">
            <div>
              <span className="font-bold text-white text-sm">Zero-Key Demonstration Mode</span>
              <p className="text-xs text-slate-400 mt-0.5">Operates fully without external API keys or Supabase credentials using local simulation data.</p>
            </div>
            <button
              type="button"
              onClick={toggleDemoMode}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                isDemoMode ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/20' : 'bg-slate-800 text-slate-300'
              }`}
            >
              <span>{isDemoMode ? 'DEMO MODE ACTIVE' : 'LIVE API MODE'}</span>
            </button>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Supabase Project URL</label>
              <input
                type="text"
                value={supabaseUrl}
                onChange={e => setSupabaseUrl(e.target.value)}
                placeholder="https://your-project.supabase.co"
                className="w-full bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-xl px-3.5 py-2.5 outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Google Gemini API Key</label>
              <input
                type="password"
                value={geminiKey}
                onChange={e => setGeminiKey(e.target.value)}
                placeholder="AIzaSy..."
                className="w-full bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-xl px-3.5 py-2.5 outline-none focus:border-cyan-500 font-mono"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">Secrets are injected securely at runtime and never exposed in client bundles.</span>
            </div>
          </div>

          <button
            type="submit"
            className="flex items-center space-x-2 px-5 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs rounded-xl transition shadow-lg cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Save Configuration</span>
          </button>
        </form>

        {/* Instructions Side Card */}
        <div className="bg-[#172338] p-6 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center space-x-2 text-amber-400 font-bold text-sm">
            <Shield className="w-4 h-4" />
            <span>Hackathon Judge Quick Start</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            RESILIENCE360 AI is designed to run instantly out of the box in <strong>Zero-Key Demonstration Mode</strong>. No API keys or external sign-ups are required to explore all modules, maps, and AI workflows.
          </p>
          <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-400 space-y-1">
            <p>✔ Open-Meteo Weather: Active</p>
            <p>✔ NASA POWER Climate: Simulated Fallback</p>
            <p>✔ Gemini URIE Engine: Simulated Fallback</p>
          </div>
        </div>
      </div>
    </div>
  );
};
