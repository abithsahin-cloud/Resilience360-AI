import React from 'react';
import { GeospatialMap } from '../components/map/GeospatialMap';
import { useResilience, TN_DISTRICTS } from '../context/ResilienceContext';
import { Globe, MapPin } from 'lucide-react';

export const MapPage: React.FC = () => {
  const { selectedDistrict, setSelectedDistrict } = useResilience();

  return (
    <div className="min-h-screen bg-[#0B1220] text-slate-100 p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-800 pb-5 gap-4">
        <div>
          <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold uppercase tracking-wider">
            <Globe className="w-4 h-4" />
            <span>PostGIS Geospatial Theatre</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white mt-1">Interactive Risk & Relief Map</h1>
          <p className="text-slate-400 text-xs mt-1">
            Real-time hazard overlays, flood risk buffers, and emergency supply routing corridors.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <select
            value={selectedDistrict.id}
            onChange={(e) => {
              const d = TN_DISTRICTS.find(item => item.id === Number(e.target.value));
              if (d) setSelectedDistrict(d);
            }}
            className="bg-[#172338] border border-slate-700 text-slate-200 text-xs rounded-xl px-3 py-2.5 outline-none focus:border-cyan-500"
          >
            {TN_DISTRICTS.map((d) => (
              <option key={d.id} value={d.id}>{d.name} District, TN</option>
            ))}
          </select>
        </div>
      </div>

      <div className="w-full h-[700px]">
        <GeospatialMap />
      </div>
    </div>
  );
};
