import React, { useState, useEffect } from 'react';
import { apiManager, ProviderStatus } from '../lib/apiManager';
import { Server, Activity, CheckCircle2, AlertTriangle, RefreshCw, Globe, Database, ShieldCheck, Zap } from 'lucide-react';

export const ApiManagerPage: React.FC = () => {
  const [providers, setProviders] = useState<ProviderStatus[]>([]);
  const [testingKey, setTestingKey] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<string | null>(null);

  const loadProviders = () => {
    setProviders(apiManager.getStatuses());
  };

  useEffect(() => {
    loadProviders();
  }, []);

  const handleTestProvider = async (key: string) => {
    setTestingKey(key);
    setTestResult(null);
    try {
      if (key === 'openMeteo') {
        await apiManager.fetchOpenMeteoWeather(13.0827, 80.2707);
      } else if (key === 'nasaPower') {
        await apiManager.fetchNasaPowerClimate(13.0827, 80.2707);
      } else if (key === 'copernicus') {
        await apiManager.fetchCopernicusAtmosphere(13.0827, 80.2707);
      } else if (key === 'dataGovIn') {
        await apiManager.fetchAgriMarketData('Chennai');
      } else if (key === 'osmRouting') {
        await apiManager.fetchRoutingPath([13.0827, 80.2707], [11.748, 79.7714]);
      } else {
        await new Promise(r => setTimeout(r, 600));
      }
      loadProviders();
      setTestResult(`Successfully tested and validated ${key} endpoint.`);
    } catch (err: any) {
      setTestResult(`Test failed for ${key}: ${err.message}`);
    } finally {
      setTestingKey(null);
    }
  };

  return (
    <div className="min-h-screen bg-[#0B1220] text-slate-100 p-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-800 pb-5 gap-4">
        <div>
          <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold uppercase tracking-wider">
            <Globe className="w-4 h-4" />
            <span>Central API Integration Manager</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white mt-1">External Data Sources & Intelligence</h1>
          <p className="text-slate-400 text-xs mt-1">
            Real-time health monitoring, source attribution, response validation, timeout management, and caching for all external endpoints.
          </p>
        </div>

        <button
          onClick={loadProviders}
          className="flex items-center space-x-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl transition border border-slate-700 cursor-pointer"
        >
          <RefreshCw className="w-4 h-4 text-cyan-400" />
          <span>Refresh All Statuses</span>
        </button>
      </div>

      {testResult && (
        <div className="bg-cyan-950/40 border border-cyan-500/50 p-4 rounded-xl text-xs text-cyan-200 flex items-center justify-between">
          <span>{testResult}</span>
          <button onClick={() => setTestResult(null)} className="text-cyan-400 hover:underline font-bold">Dismiss</button>
        </div>
      )}

      {/* Provider Status Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {providers.map((p, idx) => {
          const isConnected = p.status === 'CONNECTED';
          const keyMap = ['openMeteo', 'nasaPower', 'copernicus', 'dataGovIn', 'osmRouting', 'geminiAi'][idx];

          return (
            <div key={p.name} className="bg-[#182538] p-6 rounded-2xl border border-slate-800 space-y-4 flex flex-col justify-between shadow-xl">
              <div className="space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-bold text-white text-base">{p.name}</h3>
                    <p className="text-[11px] text-slate-400 font-mono mt-0.5 truncate max-w-[220px]" title={p.endpoint}>
                      {p.endpoint}
                    </p>
                  </div>
                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                    isConnected ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-amber-500/20 text-amber-400'
                  }`}>
                    {p.status}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs text-slate-300 pt-2 border-t border-slate-800">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Source Attribution:</span>
                    <span className="text-right font-medium text-slate-200 max-w-[160px] truncate" title={p.sourceAttribution}>
                      {p.sourceAttribution}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Response Time:</span>
                    <span className="font-mono text-cyan-400">{p.responseTimeMs} ms</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Cache Status:</span>
                    <span className="font-mono text-emerald-400">{p.cacheStatus}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Last Sync:</span>
                    <span className="font-mono text-[10px] text-slate-400">
                      {p.lastSuccessfulUpdate ? new Date(p.lastSuccessfulUpdate).toLocaleTimeString() : 'Never'}
                    </span>
                  </div>
                </div>
              </div>

              <button
                disabled={testingKey === keyMap}
                onClick={() => handleTestProvider(keyMap)}
                className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-cyan-400 font-semibold rounded-xl text-xs border border-slate-700 transition flex items-center justify-center space-x-2 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${testingKey === keyMap ? 'animate-spin' : ''}`} />
                <span>{testingKey === keyMap ? 'Validating Endpoint...' : 'Test Connection'}</span>
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
