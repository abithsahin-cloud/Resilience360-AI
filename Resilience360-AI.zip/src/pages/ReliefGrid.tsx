import React from 'react';
import { useResilience } from '../context/ResilienceContext';
import { useDemoMode } from '../context/DemoModeContext';
import { Truck, AlertTriangle, Package } from 'lucide-react';

export const ReliefGrid: React.FC = () => {
  const { selectedDistrict, isSimulatingDisaster } = useResilience();
  const { isDemoMode } = useDemoMode();

  return (
    <div className="min-h-screen bg-[#0B1220] text-slate-100 p-6 lg:p-8 space-y-8">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-[#2B3B50] pb-6 gap-4">
        <div>
          <div className="flex items-center space-x-2 text-[#F59E0B] text-xs font-bold uppercase tracking-wider">
            <Truck className="w-4 h-4" />
            <span>ReliefGrid Logistics Workspace</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-extrabold text-white mt-1">Emergency Logistics & Resource Dispatch</h1>
          <p className="text-slate-400 text-xs mt-1">
            Warehouse inventory tracking, NDRF/SDRF deployment protocols, and supply route coordination for {selectedDistrict.name}. {isDemoMode && <span className="text-amber-400 font-semibold">(DEMO MODE)</span>}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#111C2E] p-6 rounded-2xl border border-[#2B3B50] space-y-4 shadow-xl">
          <div className="flex items-center space-x-2 text-[#F59E0B] font-bold text-sm">
            <Truck className="w-4 h-4" />
            <span>Active Deployment Units</span>
          </div>
          <div className="text-3xl font-extrabold text-white">{isSimulatingDisaster ? '18 Teams' : '2 Teams'}</div>
          <p className="text-xs text-slate-400">State Disaster Response Force (SDRF) & Fire Services stationed.</p>
          <div className="pt-3 border-t border-[#2B3B50] text-xs text-slate-400 flex justify-between">
            <span>Response Readiness:</span>
            <span className="text-[#16A36A] font-bold">&lt; 20 minutes</span>
          </div>
        </div>

        <div className="bg-[#111C2E] p-6 rounded-2xl border border-[#2B3B50] space-y-4 shadow-xl">
          <div className="flex items-center space-x-2 text-[#22C5D8] font-bold text-sm">
            <Package className="w-4 h-4" />
            <span>Warehouse Rations Stock</span>
          </div>
          <div className="text-3xl font-extrabold text-white">12,500 Packets</div>
          <p className="text-xs text-slate-400">Dry ration kits, drinking water cans, and medical kits.</p>
          <div className="pt-3 border-t border-[#2B3B50] text-xs text-slate-400 flex justify-between">
            <span>Storage Capacity:</span>
            <span className="text-white font-mono">88% Utilized</span>
          </div>
        </div>

        <div className="bg-[#111C2E] p-6 rounded-2xl border border-[#2B3B50] space-y-4 shadow-xl">
          <div className="flex items-center space-x-2 text-red-400 font-bold text-sm">
            <AlertTriangle className="w-4 h-4" />
            <span>Active Incident Reports</span>
          </div>
          <div className="text-3xl font-extrabold text-white">{isSimulatingDisaster ? '3 Incidents' : '0 Incidents'}</div>
          <p className="text-xs text-slate-400">Real-time citizen SOS & sensor alarms.</p>
          <div className="pt-3 border-t border-[#2B3B50] text-xs text-slate-400 flex justify-between">
            <span>Verification Status:</span>
            <span className="text-[#22C5D8] font-bold">AI Verified</span>
          </div>
        </div>
      </div>
    </div>
  );
};
