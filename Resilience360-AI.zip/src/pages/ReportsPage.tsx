import React, { useState } from 'react';
import { useResilience } from '../context/ResilienceContext';
import { useDemoMode } from '../context/DemoModeContext';
import { FileText, Download, Printer, Shield, CheckCircle2, Cpu } from 'lucide-react';

export const ReportsPage: React.FC = () => {
  const { selectedDistrict, intelligenceInsight } = useResilience();
  const { isDemoMode } = useDemoMode();
  const [downloading, setDownloading] = useState(false);

  const handleExportJson = () => {
    setDownloading(true);
    setTimeout(() => {
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(intelligenceInsight || {}, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", `resilience360_${selectedDistrict.name}_report.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      setDownloading(false);
    }, 600);
  };

  return (
    <div className="min-h-screen bg-[#0B1220] text-slate-100 p-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-800 pb-5 gap-4">
        <div>
          <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold uppercase tracking-wider">
            <FileText className="w-4 h-4" />
            <span>Situation Reporting & Executive Briefs</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white mt-1">Consolidated Situation Report (SITREP)</h1>
          <p className="text-slate-400 text-xs mt-1">
            Automated multi-hazard intelligence report for {selectedDistrict.name} District. {isDemoMode && <span className="text-amber-400 font-semibold">(DEMO MODE DATA)</span>}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleExportJson}
            disabled={downloading}
            className="flex items-center space-x-2 px-4 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs rounded-xl transition shadow-lg cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>{downloading ? 'Generating...' : 'Export JSON SITREP'}</span>
          </button>

          <button
            onClick={() => window.print()}
            className="flex items-center space-x-2 px-4 py-2.5 bg-[#172338] hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl transition border border-slate-700 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Report Document Container */}
      <div className="bg-[#172338] p-8 rounded-2xl border border-slate-800 space-y-6 max-w-4xl mx-auto shadow-2xl print:bg-white print:text-black">
        <div className="flex justify-between items-start border-b border-slate-800 pb-6">
          <div>
            <div className="flex items-center space-x-2 text-cyan-400 font-extrabold tracking-widest text-sm">
              <Shield className="w-5 h-5" />
              <span>RESILIENCE360 AI — OFFICIAL SITREP</span>
            </div>
            <h2 className="text-2xl font-bold text-white mt-2">Disaster Management & Preparedness Brief</h2>
            <p className="text-xs text-slate-400 mt-1">Target Region: {selectedDistrict.name} District, {selectedDistrict.state}</p>
          </div>
          <div className="text-right text-xs font-mono text-slate-400">
            <p>Timestamp: {new Date().toISOString()}</p>
            <p className="text-emerald-400">● URIE Verified Brief</p>
          </div>
        </div>

        <div className="space-y-4 text-sm leading-relaxed text-slate-300">
          <div>
            <h3 className="text-xs font-bold text-cyan-400 uppercase tracking-wider mb-1">1. Executive Summary & Event Trigger</h3>
            <p>
              {intelligenceInsight?.triggerEvent || 'Severe precipitation anomaly and convective cloudburst advisory active across river basin.'}
            </p>
          </div>

          <div>
            <h3 className="text-xs font-bold text-cyan-400 uppercase tracking-wider mb-1">2. Climate & Hydrological Assessment</h3>
            <p>
              {intelligenceInsight?.climateAssessment || 'Rainfall exceeding 148mm/hr with high risk of riverine inundation in coastal and deltaic zones.'}
            </p>
          </div>

          <div>
            <h3 className="text-xs font-bold text-cyan-400 uppercase tracking-wider mb-1">3. Agricultural & Crop Vulnerability</h3>
            <p>
              {intelligenceInsight?.agriculturalImpact || 'Immediate threat to standing Paddy crops at vegetative growth stages. High risk of waterlogging.'}
            </p>
          </div>

          <div>
            <h3 className="text-xs font-bold text-cyan-400 uppercase tracking-wider mb-1">4. Critical Infrastructure & Utilities</h3>
            <p>
              {intelligenceInsight?.infrastructureStatus || '3 primary electrical substations operating under flood watch. Water treatment plants on backup power.'}
            </p>
          </div>

          <div>
            <h3 className="text-xs font-bold text-cyan-400 uppercase tracking-wider mb-1">5. Emergency Coordination Action Plan</h3>
            <ul className="list-disc pl-5 space-y-1 mt-1">
              {intelligenceInsight?.emergencyCoordinationPlan?.immediateActions.map((action, i) => (
                <li key={i}>{action}</li>
              )) || <li>Pre-position SDRF rescue boats and emergency water rations in low-lying sectors.</li>}
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-6 flex justify-between items-center text-xs text-slate-400">
          <span>Authorised by: State Disaster Management Authority (TNSDMA)</span>
          <span className="text-cyan-400 font-mono">Confidence Index: {intelligenceInsight?.confidenceScore || 92.4}%</span>
        </div>
      </div>
    </div>
  );
};
