import React from 'react';
import { useResilience } from '../context/ResilienceContext';
import { Play, RotateCcw, ArrowRight, ShieldAlert, Cpu, Database, Check } from 'lucide-react';

export const PresentationMode: React.FC = () => {
  const { 
    selectedDistrict, 
    isSimulatingDisaster, 
    simulationStep, 
    startEmergencySimulation, 
    advanceSimulationStep, 
    resetSimulation 
  } = useResilience();

  const presentationSteps = [
    {
      step: 1,
      title: 'Baseline Ingestion & Multi-Domain Monitoring',
      desc: 'Platform constantly ingests Open-Meteo satellite atmospheric readings, grid telemetry, and crop records for Tamil Nadu districts.',
      activeStatus: 'Atmospheric baselines normal. Soil moisture nominal.',
    },
    {
      step: 2,
      title: 'Hypothetical Extreme Weather Cloudburst Event',
      desc: 'Simulated 148mm/hr precipitation event hits the river basin. PostGIS models immediate embankment saturation and deltaic paddy flood exposure.',
      activeStatus: 'Flood vulnerability index surges to 89%. Flash flood alert activated.',
    },
    {
      step: 3,
      title: 'URIE Cross-Module Synthesis',
      desc: 'Gemini-powered URIE evaluates impacts: 3 electrical substations require de-watering, while paddy fields require emergency drainage channels.',
      activeStatus: 'Coordinated emergency advisory generated with 92% confidence.',
    },
    {
      step: 4,
      title: 'Human-in-the-Loop Logistics & Relief Mobilization',
      desc: 'Command approves the dispatch: inflatable rafts, water filters, and food packets are routed from regional depots via safe corridors.',
      activeStatus: 'Supply convoys dispatched. Mission status: Responding.',
    },
  ];

  return (
    <div className="min-h-screen bg-[#070C14] text-slate-100 p-8 flex flex-col items-center">
      <div className="max-w-5xl w-full space-y-8">
        {/* Header */}
        <div className="text-center space-y-2">
          <span className="px-3 py-1 bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 rounded-full text-xs font-bold tracking-widest uppercase">
            Hackathon Executive Experience
          </span>
          <h1 className="text-4xl font-extrabold text-white tracking-tight">
            RESILIENCE360: 3-Minute Live Demonstration
          </h1>
          <p className="text-slate-400 text-sm max-w-2xl mx-auto">
            Witness how an extreme climate event dynamically propagates across Agriculture, Smart Grids, and Disaster Logistics in {selectedDistrict.name}.
          </p>
        </div>

        {/* Step Controls */}
        <div className="flex justify-center items-center gap-4">
          {!isSimulatingDisaster ? (
            <button
              onClick={startEmergencySimulation}
              className="flex items-center space-x-2 px-6 py-3 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded-xl transition shadow-lg shadow-cyan-500/20 cursor-pointer"
            >
              <Play className="w-5 h-5 fill-current" />
              <span>Launch 4-Phase Disaster Scenario</span>
            </button>
          ) : (
            <div className="flex items-center gap-3">
              <button
                onClick={advanceSimulationStep}
                disabled={simulationStep >= 4}
                className={`flex items-center space-x-2 px-6 py-3 rounded-xl font-bold transition cursor-pointer ${
                  simulationStep < 4
                    ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/20'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                <span>Advance to Stage {simulationStep + 1}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={resetSimulation}
                className="flex items-center space-x-2 px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition border border-slate-700 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Reset Demo</span>
              </button>
            </div>
          )}
        </div>

        {/* Interactive Step Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {presentationSteps.map((item) => {
            const isCurrent = isSimulatingDisaster && simulationStep === item.step;
            const isPast = isSimulatingDisaster && simulationStep > item.step;

            return (
              <div
                key={item.step}
                className={`p-6 rounded-2xl border transition-all duration-300 relative ${
                  isCurrent
                    ? 'bg-slate-900 border-cyan-400 shadow-xl shadow-cyan-950/50 scale-[1.02]'
                    : isPast
                    ? 'bg-slate-950/80 border-slate-800 opacity-60'
                    : 'bg-slate-950/40 border-slate-800/60'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <span className={`text-xs font-bold px-2 py-1 rounded-md ${
                    isCurrent ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                  }`}>
                    PHASE 0{item.step}
                  </span>
                  {isPast && <Check className="w-5 h-5 text-emerald-400" />}
                </div>
                <h3 className="text-lg font-bold text-white mb-2">{item.title}</h3>
                <p className="text-xs text-slate-400 leading-relaxed mb-4">{item.desc}</p>
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800/80 text-xs font-mono">
                  <span className="text-slate-500 block text-[10px] uppercase">Telemetry / Logic Output:</span>
                  <span className={isCurrent ? 'text-amber-400 font-semibold' : 'text-slate-400'}>
                    {item.activeStatus}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Technical Architecture Validation Footnote */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 flex flex-wrap justify-between items-center text-xs text-slate-400">
          <div className="flex items-center space-x-2">
            <Cpu className="w-4 h-4 text-cyan-400" />
            <span>Gemini 1.5 Flash URIE Inference Engine Active</span>
          </div>
          <div className="flex items-center space-x-2">
            <Database className="w-4 h-4 text-emerald-400" />
            <span>Supabase PostgreSQL + PostGIS Spatial Indexing</span>
          </div>
          <div className="flex items-center space-x-2">
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            <span>Strict Role-Based Human Authorization Safeguards</span>
          </div>
        </div>
      </div>
    </div>
  );
};
