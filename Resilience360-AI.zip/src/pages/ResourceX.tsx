import React from 'react';
import { useResilience } from '../context/ResilienceContext';
import { useDemoMode } from '../context/DemoModeContext';
import { Zap, Droplet, Sun } from 'lucide-react';

export const ResourceX: React.FC = () => {
  const { selectedDistrict, isSimulatingDisaster } = useResilience();
  const { isDemoMode } = useDemoMode();

  return (
    <div className="min-h-screen bg-[#0B1220] text-slate-100 p-6 lg:p-8 space-y-8">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-[#2B3B50] pb-6 gap-4">
        <div>
          <div className="flex items-center space-x-2 text-[#17A6A1] text-xs font-bold uppercase tracking-wider">
            <Zap className="w-4 h-4" />
            <span>ResourceX Infrastructure Workspace</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-extrabold text-white mt-1">Critical Infrastructure & Grid Telemetry</h1>
          <p className="text-slate-400 text-xs mt-1">
            Power substations, water reservoirs, and renewable energy grid stability for {selectedDistrict.name}. {isDemoMode && <span className="text-amber-400 font-semibold">(DEMO MODE)</span>}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#111C2E] p-6 rounded-2xl border border-[#2B3B50] space-y-4 shadow-xl">
          <div className="flex justify-between items-center text-[#17A6A1] font-bold text-sm">
            <span className="flex items-center space-x-2">
              <Zap className="w-4 h-4" />
              <span>Electrical Substation Grid</span>
            </span>
            <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold ${isSimulatingDisaster ? 'bg-red-500/20 text-red-400' : 'bg-[#16A36A]/20 text-[#16A36A]'}`}>
              {isSimulatingDisaster ? 'BREACH WARNING' : 'STABLE'}
            </span>
          </div>
          <div className="text-3xl font-extrabold text-white">{isSimulatingDisaster ? '1,420 MW' : '890 MW'}</div>
          <p className="text-xs text-slate-400">Total regional load out of 1,500 MW capacity.</p>
          <div className="pt-3 border-t border-[#2B3B50] text-xs text-slate-400 flex justify-between">
            <span>Substations Online:</span>
            <span className="text-white font-mono">{isSimulatingDisaster ? '7 / 10' : '10 / 10'}</span>
          </div>
        </div>

        <div className="bg-[#111C2E] p-6 rounded-2xl border border-[#2B3B50] space-y-4 shadow-xl">
          <div className="flex justify-between items-center text-[#22C5D8] font-bold text-sm">
            <span className="flex items-center space-x-2">
              <Droplet className="w-4 h-4" />
              <span>Water Reservoir Storage</span>
            </span>
            <span className="text-[10px] px-2.5 py-0.5 rounded-full font-bold bg-[#22C5D8]/20 text-[#22C5D8]">
              {isSimulatingDisaster ? 'SPILLWAY ALERT' : 'NOMINAL'}
            </span>
          </div>
          <div className="text-3xl font-extrabold text-white">{isSimulatingDisaster ? '96.5%' : '62.0%'}</div>
          <p className="text-xs text-slate-400">Basin: {selectedDistrict.major_river_basin}</p>
          <div className="pt-3 border-t border-[#2B3B50] text-xs text-slate-400 flex justify-between">
            <span>Inflow Rate:</span>
            <span className="text-white font-mono">{isSimulatingDisaster ? '14,200 cusecs' : '1,850 cusecs'}</span>
          </div>
        </div>

        <div className="bg-[#111C2E] p-6 rounded-2xl border border-[#2B3B50] space-y-4 shadow-xl">
          <div className="flex justify-between items-center text-[#16A36A] font-bold text-sm">
            <span className="flex items-center space-x-2">
              <Sun className="w-4 h-4" />
              <span>Solar Farm Generation</span>
            </span>
            <span className="text-[10px] px-2.5 py-0.5 rounded-full font-bold bg-[#16A36A]/20 text-[#16A36A]">ACTIVE</span>
          </div>
          <div className="text-3xl font-extrabold text-white">340 MW</div>
          <p className="text-xs text-slate-400">Photovoltaic arrays functioning at 78% efficiency.</p>
          <div className="pt-3 border-t border-[#2B3B50] text-xs text-slate-400 flex justify-between">
            <span>Grid Feed:</span>
            <span className="text-white font-mono">Synchronized</span>
          </div>
        </div>
      </div>
    </div>
  );
};
