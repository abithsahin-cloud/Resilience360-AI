export type DataOrigin = 'LIVE' | 'CACHED' | 'SIMULATED' | 'FALLBACK';
export type RiskLevel = 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';

export interface District {
  id: number;
  name: string;
  state: string;
  latitude: number;
  longitude: number;
  coastal: boolean;
  major_river_basin: string;
  soil_primary: string;
}

export interface LiveWeatherData {
  temperature: number;
  relativeHumidity: number;
  precipitation: number;
  windSpeed: number;
  weatherCode: number;
  forecastRainSum: number[];
  forecastMaxTemp: number[];
  forecastDates: string[];
  origin: DataOrigin;
  timestamp: string;
}

export interface ClimateAssessment {
  floodRiskScore: number;
  droughtRiskScore: number;
  heatRiskScore: number;
  compositeLevel: RiskLevel;
  explanation: string;
}

export interface AgriCropRecommendation {
  cropName: string;
  suitabilityScore: number;
  growingDurationDays: number;
  waterRequirement: 'LOW' | 'MEDIUM' | 'HIGH';
  keyVulnerability: string;
  recommendedPractices: string[];
}

export interface ResourceMetric {
  gridElectricityDemandMW: number;
  availableCapacityMW: number;
  waterReservoirFillPct: number;
  solarGenerationMW: number;
  criticalAlert?: string;
}

export interface ReliefInventoryItem {
  id: string;
  warehouseName: string;
  itemCategory: string;
  itemName: string;
  quantityAvailable: number;
  unit: string;
}

export interface UnifiedResilienceInsight {
  districtName: string;
  triggerEvent: string;
  overallThreatScore: number; // 0 - 100
  climateAssessment: string;
  agriculturalImpact: string;
  infrastructureStatus: string;
  emergencyCoordinationPlan: {
    immediateActions: string[];
    logisticsRequired: { item: string; quantity: number; unit: string }[];
    evacuationPriority: 'NONE' | 'STANDBY' | 'MANDATORY';
  };
  confidenceScore: number;
  isHumanApprovalRequired: boolean;
  timestamp: string;
  origin: DataOrigin;
}
