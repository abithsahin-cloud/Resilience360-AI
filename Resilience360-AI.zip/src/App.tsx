import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import { ResilienceProvider } from './context/ResilienceContext';
import { AuthProvider } from './context/AuthContext';
import { DemoModeProvider, useDemoMode } from './context/DemoModeContext';
import { UnifiedDashboard } from './pages/UnifiedDashboard';
import { AgroVision } from './pages/AgroVision';
import { ClimaTrack } from './pages/ClimaTrack';
import { ResourceX } from './pages/ResourceX';
import { ReliefGrid } from './pages/ReliefGrid';
import { PresentationMode } from './pages/PresentationMode';
import { DatabaseStatus } from './pages/DatabaseStatus';
import { ApiManagerPage } from './pages/ApiManagerPage';
import { UrieWorkflowPage } from './pages/UrieWorkflowPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { ReportsPage } from './pages/ReportsPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { MapPage } from './pages/MapPage';
import { SettingsPage } from './pages/SettingsPage';
import { 
  LayoutDashboard, 
  Sprout, 
  CloudRain, 
  Zap, 
  Truck, 
  Presentation, 
  Shield,
  Database,
  Globe,
  Cpu,
  BarChart3,
  FileText,
  Bell,
  MapPin,
  Settings,
  Menu,
  X,
  Search
} from 'lucide-react';

const EnterpriseHeader: React.FC<{ onToggleSidebar: () => void }> = ({ onToggleSidebar }) => {
  const { isDemoMode, toggleDemoMode } = useDemoMode();

  return (
    <header className="h-16 bg-[#0B1220] border-b border-slate-800 px-6 flex items-center justify-between z-30 sticky top-0">
      <div className="flex items-center space-x-4">
        <button 
          onClick={onToggleSidebar}
          className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white md:hidden transition cursor-pointer"
        >
          <Menu className="w-5 h-5" />
        </button>
      </div>

      <div className="flex items-center space-x-4">
        {/* Live / Demo Mode Toggle Switch */}
        <button
          onClick={toggleDemoMode}
          className={`flex items-center space-x-2 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
            isDemoMode 
              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30' 
              : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
          }`}
          title="Toggle between Live API Mode and Zero-Key Demo Mode"
        >
          <span className={`w-2 h-2 rounded-full ${isDemoMode ? 'bg-amber-400 animate-pulse' : 'bg-emerald-400'}`}></span>
          <span>{isDemoMode ? 'MODE: DEMO (ZERO-KEY)' : 'MODE: LIVE API'}</span>
        </button>

        <Link to="/notifications" className="p-2 hover:bg-slate-800 rounded-xl text-slate-400 hover:text-white relative transition">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-cyan-400"></span>
        </Link>

        <div className="flex items-center space-x-3 pl-2 border-l border-slate-800">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center font-bold text-xs text-white shadow-lg">
            DC
          </div>
                    <div className="hidden lg:block text-left">
            <div className="text-xs font-bold text-slate-200">Dr. Arul Kumaran</div>
            <div className="text-[10px] text-cyan-400">State Coordinator</div>
          </div>

        </div>
      </div>
    </header>
  );
};

const NavigationSidebar: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const location = useLocation();
  const navItems = [
    { label: 'Overview', path: '/', icon: LayoutDashboard },
    { label: 'AgroVision', path: '/agrovision', icon: Sprout },
    { label: 'ClimaTrack', path: '/climatrack', icon: CloudRain },
    { label: 'ResourceX', path: '/resourcex', icon: Zap },
    { label: 'ReliefGrid', path: '/reliefgrid', icon: Truck },
    { label: 'Unified Intelligence', path: '/urie', icon: Cpu },
    { label: 'Live Map', path: '/map', icon: MapPin },
    { label: 'Analytics', path: '/analytics', icon: BarChart3 },
    { label: 'Reports (SITREP)', path: '/reports', icon: FileText },
    { label: 'Notifications', path: '/notifications', icon: Bell },
    { label: 'API Integrations', path: '/apis', icon: Globe },
    { label: 'Database & Health', path: '/database', icon: Database },
    { label: 'Settings', path: '/settings', icon: Settings },
    { label: 'Presentation Mode', path: '/experience', icon: Presentation },
  ];

  return (
    <aside className={`w-64 bg-[#070C14] border-r border-slate-800 p-4 flex flex-col justify-between fixed md:static inset-y-0 left-0 z-40 transition-transform duration-300 ${
      isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
    }`}>
      <div className="space-y-6">
        <div className="flex items-center justify-between px-2 py-1">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <span className="font-extrabold text-sm tracking-wider text-white block">RESILIENCE360</span>
              <span className="text-[9px] font-mono text-cyan-400 tracking-widest uppercase">AI Command Centre</span>
            </div>
          </div>
          <button onClick={onClose} className="p-1 md:hidden text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="space-y-1 overflow-y-auto max-h-[calc(100vh-220px)] pr-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={onClose}
                className={`flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition ${
                  active
                    ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
                    : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-500 mt-4">
        Platform: <strong className="text-slate-300">Enterprise v2.5</strong>
        <div className="text-[10px] text-emerald-400 mt-0.5">● Subsystems Operational</div>
      </div>
    </aside>
  );
};

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <AuthProvider>
      <DemoModeProvider>
        <ResilienceProvider>
          <BrowserRouter>
            <div className="flex min-h-screen bg-[#0B1220] font-sans">
              <NavigationSidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
              <div className="flex-1 flex flex-col min-w-0">
                <EnterpriseHeader onToggleSidebar={() => setSidebarOpen(prev => !prev)} />
                <main className="flex-1 overflow-y-auto">
                  <Routes>
                    <Route path="/" element={<UnifiedDashboard />} />
                    <Route path="/agrovision" element={<AgroVision />} />
                    <Route path="/climatrack" element={<ClimaTrack />} />
                    <Route path="/resourcex" element={<ResourceX />} />
                    <Route path="/reliefgrid" element={<ReliefGrid />} />
                    <Route path="/urie" element={<UrieWorkflowPage />} />
                    <Route path="/map" element={<MapPage />} />
                    <Route path="/analytics" element={<AnalyticsPage />} />
                    <Route path="/reports" element={<ReportsPage />} />
                    <Route path="/notifications" element={<NotificationsPage />} />
                    <Route path="/apis" element={<ApiManagerPage />} />
                    <Route path="/database" element={<DatabaseStatus />} />
                    <Route path="/settings" element={<SettingsPage />} />
                    <Route path="/experience" element={<PresentationMode />} />
                    <Route path="*" element={<UnifiedDashboard />} />
                  </Routes>
                </main>
              </div>
            </div>
          </BrowserRouter>
        </ResilienceProvider>
      </DemoModeProvider>
    </AuthProvider>
  );
}
