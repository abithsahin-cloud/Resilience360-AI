import { LiveWeatherData } from '../types';

export async function fetchLiveDistrictWeather(
  lat: number,
  lon: number
): Promise<LiveWeatherData> {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,weather_code&daily=precipitation_sum,temperature_2m_max&timezone=Asia%2FKolkata`;

  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Open-Meteo response status ${response.status}`);
    }
    const data = await response.json();

    return {
      temperature: data.current.temperature_2m,
      relativeHumidity: data.current.relative_humidity_2m,
      precipitation: data.current.precipitation,
      windSpeed: data.current.wind_speed_10m,
      weatherCode: data.current.weather_code,
      forecastRainSum: data.daily.precipitation_sum || [],
      forecastMaxTemp: data.daily.temperature_2m_max || [],
      forecastDates: data.daily.time || [],
      origin: 'LIVE',
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    console.warn('Live API request failed, engaging deterministic fallback:', error);
    return {
      temperature: 31.8,
      relativeHumidity: 78,
      precipitation: 4.2,
      windSpeed: 14.5,
      weatherCode: 61,
      forecastRainSum: [12.0, 45.5, 62.1, 15.0, 2.0, 0.0, 0.0],
      forecastMaxTemp: [32, 29, 28, 30, 31, 33, 34],
      forecastDates: Array.from({ length: 7 }, (_, i) => {
        const d = new Date();
        d.setDate(d.getDate() + i);
        return d.toISOString().split('T')[0];
      }),
      origin: 'FALLBACK',
      timestamp: new Date().toISOString(),
    };
  }
}
