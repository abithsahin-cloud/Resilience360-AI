import { supabase } from './supabase';

/**
 * CRUD Operations Wrapper for Resilience360 AI Modules
 */

// 1. AGROVISION: Mandi Prices & Crop Diagnoses
export async function fetchMandiPrices() {
  try {
    const { data, error } = await supabase.from('mandi_prices').select('*').order('created_at', { ascending: false });
    if (error) throw error;
    return data && data.length > 0 ? data : getFallbackMandiPrices();
  } catch (err) {
    console.warn('Supabase fetch mandi prices fallback:', err);
    return getFallbackMandiPrices();
  }
}

export async function createMandiPriceRecord(record: {
  district_id: number;
  market_name: string;
  commodity: string;
  min_price: number;
  max_price: number;
  modal_price: number;
  price_date: string;
}) {
  try {
    const { data, error } = await supabase.from('mandi_prices').insert([record]).select();
    if (error) throw error;
    return { success: true, data };
  } catch (err: any) {
    console.error('Error inserting mandi price:', err);
    return { success: false, error: err.message };
  }
}

// 2. CLIMATRACK: Climate Assessments
export async function fetchClimateAssessments() {
  try {
    const { data, error } = await supabase.from('climate_assessments').select('*, districts(name)').order('created_at', { ascending: false });
    if (error) throw error;
    return data && data.length > 0 ? data : getFallbackClimateAssessments();
  } catch (err) {
    console.warn('Supabase fetch climate assessments fallback:', err);
    return getFallbackClimateAssessments();
  }
}

// 3. RESOURCEX: Infrastructure & Utilities
export async function fetchResourceInfrastructure() {
  try {
    const { data, error } = await supabase.from('resource_infrastructure').select('*, districts(name)');
    if (error) throw error;
    return data && data.length > 0 ? data : getFallbackInfrastructure();
  } catch (err) {
    console.warn('Supabase fetch resource infrastructure fallback:', err);
    return getFallbackInfrastructure();
  }
}

export async function updateInfrastructureLevel(id: string, newLevel: number, status: string) {
  try {
    const { data, error } = await supabase
      .from('resource_infrastructure')
      .update({ current_level: newLevel, status, last_inspected: new Date().toISOString() })
      .eq('id', id)
      .select();
    if (error) throw error;
    return { success: true, data };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

// 4. RELIEFGRID: Emergency Incidents & Inventory
export async function fetchEmergencyIncidents() {
  try {
    const { data, error } = await supabase.from('emergency_incidents').select('*, districts(name)').order('created_at', { ascending: false });
    if (error) throw error;
    return data && data.length > 0 ? data : getFallbackIncidents();
  } catch (err) {
    console.warn('Supabase fetch emergency incidents fallback:', err);
    return getFallbackIncidents();
  }
}

export async function reportEmergencyIncident(incident: {
  district_id: number;
  incident_type: string;
  title: string;
  description: string;
  latitude: number;
  longitude: number;
  affected_population_est: number;
  severity: string;
}) {
  try {
    const { data, error } = await supabase.from('emergency_incidents').insert([incident]).select();
    if (error) throw error;
    return { success: true, data };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

export async function fetchReliefInventory() {
  try {
    const { data, error } = await supabase.from('relief_inventory').select('*, relief_warehouses(name)');
    if (error) throw error;
    return data && data.length > 0 ? data : getFallbackInventory();
  } catch (err) {
    return getFallbackInventory();
  }
}

// Fallbacks for offline / demonstration persistence
function getFallbackMandiPrices() {
  return [
    { id: '1', market_name: 'Cuddalore Regulated Market', commodity: 'Paddy (Grade A)', min_price: 2200, max_price: 2350, modal_price: 2320, price_date: new Date().toISOString().split('T')[0], origin: 'FALLBACK' },
    { id: '2', market_name: 'Chennai Uzhavar Sandhai', commodity: 'Groundnut Pods', min_price: 6200, max_price: 6600, modal_price: 6450, price_date: new Date().toISOString().split('T')[0], origin: 'FALLBACK' },
  ];
}

function getFallbackClimateAssessments() {
  return [
    { id: '1', district_id: 1, flood_risk_score: 82.5, drought_risk_score: 12.0, heat_risk_score: 45.0, composite_risk_level: 'HIGH', temperature_celsius: 31.8, origin: 'FALLBACK' }
  ];
}

function getFallbackInfrastructure() {
  return [
    { id: '1', facility_type: 'SUBSTATION', facility_name: 'Cuddalore 110kV Grid Substation', capacity_total: 150, current_level: 112, unit: 'MW', status: 'OPTIMAL', origin: 'FALLBACK' },
    { id: '2', facility_type: 'WATER_RESERVOIR', facility_name: 'Vellar Basin Reservoir', capacity_total: 45.0, current_level: 28.4, unit: 'TMC', status: 'OPTIMAL', origin: 'FALLBACK' },
  ];
}

function getFallbackIncidents() {
  return [
    { id: '1', title: 'Embankment Seepage near Vellar River', incident_type: 'FLOOD', description: 'Minor seepage detected during high discharge.', status: 'VERIFIED', severity: 'MODERATE', affected_population_est: 1200, origin: 'FALLBACK' }
  ];
}

function getFallbackInventory() {
  return [
    { id: '1', item_category: 'DRINKING_WATER', item_name: 'Purified Water Containers (20L)', quantity_available: 3500, unit: 'containers', origin: 'FALLBACK' },
    { id: '2', item_category: 'FOOD_RATIONS', item_name: 'Emergency Dry Ration Kits', quantity_available: 12000, unit: 'packets', origin: 'FALLBACK' },
  ];
}
