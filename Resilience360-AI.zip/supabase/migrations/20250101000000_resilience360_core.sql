-- Resilience360 AI Core Database Schema & Migrations
-- Target: PostgreSQL with PostGIS extension

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";

-- ENUMS
DO $$ BEGIN
  CREATE TYPE user_role AS ENUM (
    'super_admin',
    'govt_admin',
    'agricultural_user',
    'climate_analyst',
    'resource_manager',
    'emergency_coordinator',
    'public_viewer'
  );
EXCEPTION
  WHEN duplicate_object => null;
END $$;

DO $$ BEGIN
  CREATE TYPE risk_level AS ENUM ('LOW', 'MODERATE', 'HIGH', 'CRITICAL');
EXCEPTION
  WHEN duplicate_object => null;
END $$;

DO $$ BEGIN
  CREATE TYPE incident_type AS ENUM ('FLOOD', 'DROUGHT', 'CYCLONE', 'HEATWAVE', 'INFRASTRUCTURE_FAILURE');
EXCEPTION
  WHEN duplicate_object => null;
END $$;

DO $$ BEGIN
  CREATE TYPE incident_status AS ENUM ('REPORTED', 'VERIFIED', 'RESPONDING', 'CONTAINED', 'RESOLVED');
EXCEPTION
  WHEN duplicate_object => null;
END $$;

DO $$ BEGIN
  CREATE TYPE data_origin AS ENUM ('LIVE', 'CACHED', 'SIMULATED', 'FALLBACK');
EXCEPTION
  WHEN duplicate_object => null;
END $$;

-- 1. USERS & PROFILES
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY,
  full_name TEXT NOT NULL,
  role user_role DEFAULT 'public_viewer',
  organization TEXT,
  phone TEXT,
  preferred_language TEXT DEFAULT 'en',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. GEOGRAPHICAL REFERENCE DATA (Tamil Nadu Centric)
CREATE TABLE IF NOT EXISTS districts (
  id SERIAL PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  state TEXT DEFAULT 'Tamil Nadu',
  latitude NUMERIC(9,6) NOT NULL,
  longitude NUMERIC(9,6) NOT NULL,
  coastal BOOLEAN DEFAULT FALSE,
  major_river_basin TEXT,
  soil_primary TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Seed Initial Districts if empty
INSERT INTO districts (name, latitude, longitude, coastal, major_river_basin, soil_primary) VALUES
('Chennai', 13.0827, 80.2707, TRUE, 'Cooum / Adyar', 'Coastal Alluvium'),
('Cuddalore', 11.7480, 79.7714, TRUE, 'Pennaiyar / Gadilam', 'Alluvial / Red Sandy'),
('Thanjavur', 10.7870, 79.1378, FALSE, 'Cauvery Delta', 'Deltaic Alluvium'),
('Madurai', 9.9252, 78.1198, FALSE, 'Vaigai', 'Black / Clayey Red'),
('Coimbatore', 11.0168, 76.9558, FALSE, 'Noyyal', 'Red Loam')
ON CONFLICT (name) DO NOTHING;

-- 3. AGROVISION TABLES
CREATE TABLE IF NOT EXISTS farmer_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  district_id INT REFERENCES districts(id),
  land_area_hectares NUMERIC(6,2) NOT NULL,
  soil_type TEXT NOT NULL,
  irrigation_type TEXT NOT NULL,
  farming_experience_years INT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS mandi_prices (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  district_id INT REFERENCES districts(id),
  market_name TEXT NOT NULL,
  commodity TEXT NOT NULL,
  variety TEXT,
  min_price NUMERIC(10,2) NOT NULL,
  max_price NUMERIC(10,2) NOT NULL,
  modal_price NUMERIC(10,2) NOT NULL,
  price_date DATE NOT NULL,
  source TEXT DEFAULT 'Agmarknet / e-NAM',
  origin data_origin DEFAULT 'LIVE',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS crop_image_diagnoses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id),
  district_id INT REFERENCES districts(id),
  image_url TEXT NOT NULL,
  crop_name TEXT,
  detected_condition TEXT NOT NULL,
  confidence_score NUMERIC(5,2) NOT NULL,
  category TEXT NOT NULL,
  symptoms_description TEXT NOT NULL,
  recommended_actions JSONB NOT NULL,
  is_human_verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. CLIMATRACK TABLES
CREATE TABLE IF NOT EXISTS climate_assessments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  district_id INT REFERENCES districts(id),
  flood_risk_score NUMERIC(4,1) NOT NULL,
  drought_risk_score NUMERIC(4,1) NOT NULL,
  heat_risk_score NUMERIC(4,1) NOT NULL,
  composite_risk_level risk_level NOT NULL,
  rainfall_anomaly_percent NUMERIC(5,2),
  temperature_celsius NUMERIC(4,1),
  forecast_window_days INT DEFAULT 7,
  origin data_origin DEFAULT 'LIVE',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. RESOURCEX TABLES
CREATE TABLE IF NOT EXISTS resource_infrastructure (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  district_id INT REFERENCES districts(id),
  facility_type TEXT NOT NULL,
  facility_name TEXT NOT NULL,
  capacity_total NUMERIC(12,2) NOT NULL,
  current_level NUMERIC(12,2) NOT NULL,
  unit TEXT NOT NULL,
  status TEXT DEFAULT 'OPTIMAL',
  origin data_origin DEFAULT 'LIVE',
  last_inspected TIMESTAMPTZ DEFAULT NOW()
);

-- 6. RELIEFGRID TABLES
CREATE TABLE IF NOT EXISTS emergency_incidents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  district_id INT REFERENCES districts(id),
  incident_type incident_type NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  latitude NUMERIC(9,6) NOT NULL,
  longitude NUMERIC(9,6) NOT NULL,
  affected_population_est INT NOT NULL,
  status incident_status DEFAULT 'REPORTED',
  severity risk_level NOT NULL,
  created_by UUID REFERENCES profiles(id),
  origin data_origin DEFAULT 'LIVE',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS relief_warehouses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  district_id INT REFERENCES districts(id),
  name TEXT NOT NULL,
  latitude NUMERIC(9,6) NOT NULL,
  longitude NUMERIC(9,6) NOT NULL,
  capacity_metric_tons NUMERIC(10,2) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS relief_inventory (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  warehouse_id UUID REFERENCES relief_warehouses(id) ON DELETE CASCADE,
  item_category TEXT NOT NULL,
  item_name TEXT NOT NULL,
  quantity_available INT NOT NULL CHECK (quantity_available >= 0),
  unit TEXT NOT NULL,
  origin data_origin DEFAULT 'LIVE',
  last_updated TIMESTAMPTZ DEFAULT NOW()
);

-- 7. UNIFIED RESILIENCE INTELLIGENCE ENGINE (URIE) REPORTS
CREATE TABLE IF NOT EXISTS unified_resilience_reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  district_id INT REFERENCES districts(id),
  triggering_event TEXT NOT NULL,
  climate_impact_summary TEXT NOT NULL,
  agricultural_impact_summary TEXT NOT NULL,
  infrastructure_impact_summary TEXT NOT NULL,
  emergency_action_plan JSONB NOT NULL,
  risk_index NUMERIC(4,2) NOT NULL,
  is_approved_by_admin BOOLEAN DEFAULT FALSE,
  approved_by UUID REFERENCES profiles(id),
  origin data_origin DEFAULT 'SIMULATED',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ROW LEVEL SECURITY (RLS) POLICIES
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE climate_assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE emergency_incidents ENABLE ROW LEVEL SECURITY;
ALTER TABLE unified_resilience_reports ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  CREATE POLICY "Public read climate assessments" ON climate_assessments
    FOR SELECT TO authenticated, anon USING (true);
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE POLICY "Public read verified incidents" ON emergency_incidents
    FOR SELECT TO authenticated, anon USING (true);
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE POLICY "Incident insertion restricted" ON emergency_incidents
    FOR INSERT TO authenticated WITH CHECK (true);
EXCEPTION WHEN duplicate_object THEN null;
END $$;
